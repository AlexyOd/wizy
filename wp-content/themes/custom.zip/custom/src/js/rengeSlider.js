import noUISlider from './plugns/nouislider.min.js'

export default class rangeSlider{
    constructor(options) {
        this.cache(options)
        this.createSlider()
    }
    cache(options) {
        this.settings = {
            ...this.defaults,
            ...options
        }
    }
    get defaults() {
        return {
            $slider: null,
            $input: null,
            value: 0,
            min: 0,
            max: 100,   
            timer: null,
        }
    }
    createSlider() {
        const _this = this
        const min = this.getNumber(this.settings.min)
        const max = this.getNumber(this.settings.max)
        const value = this.getNumber(this.settings.value)
        const $slider = noUISlider.create(this.settings.$slider, {
            start: value,
            animate: false,
            connect: 'lower',
            range: {
                min, max
            },
            tooltips: [true],
        })

        
        $slider.on('update', function (values, handle) {
            _this.updateSliderTooltip($slider, values)
        })
    }
    getNumber(str) {
        return +str.match(/-?\d+(\.\d+)?/)[0]
    }

    updateSliderTooltip(slider, value) {
        const $tooltip = slider.getTooltips()[0];
        $tooltip.style.marginLeft = ''
        const tooltiBoundingClientRect = $tooltip.getBoundingClientRect()
        const $parent = $tooltip.closest('.noUi-base')
        const parentBoundingClientRect = $parent.getBoundingClientRect()
        
        const max = parentBoundingClientRect.x + parentBoundingClientRect.width
        const currentTooltipPosition = tooltiBoundingClientRect.x + tooltiBoundingClientRect.width

        const sum = max - currentTooltipPosition
        const sum2 = (parentBoundingClientRect.x-tooltiBoundingClientRect.x)

        if(sum <0) {
            $tooltip.style.marginLeft = sum + "px";
        }  else if(sum2 > 0) {
            $tooltip.style.marginLeft = sum2 + "px";
        } else {
            $tooltip.style.marginLeft = ''
        }
        if(this.settings.$input) {
            this.settings.$input.value = value
        }
    }
}