export default {
    init() {
        this.cache()
        this.events()
        this.handleScroll()
    },
    cache() {
        this.settings = {
            btn: '.dbtn',
            visible: 'visible'
        }
        this.$btn = document.querySelector(this.settings.btn)    
    },
    events() {
        this.$btn.addEventListener('click', this.handleClick.bind(this))
        window.addEventListener('scroll', this.handleScroll.bind(this));
    },
    handleClick() {
        window.scrollTo({ top: 0, behavior: 'smooth' })
    },
    handleScroll() {
        const screenHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

        if(window.scrollY >= screenHeight) {
            this.$btn.classList.add(this.settings.visible)
        } else {
            this.$btn.classList.remove(this.settings.visible)
        }
    }
}