import Swiper from 'swiper';
import { Autoplay } from 'swiper/modules';

export default {

    init() {
        this.cache()
    },  

    cache() {
        this.settings = {
            container: '.blog__swiper',
        }
        const $slider = document.querySelector(this.settings.container)
        if(!$slider) return
        this.$slider = new Swiper(this.settings.container, this.swiperOptions)
    },

    get swiperOptions () {
        return  {
            modules: [Autoplay],
            slidesPerView: 1,
            spaceBetween: 0,
            autoHeight: true,
            autoplay: {
                delay: 2500
            },
            breakpoints: {
                992: {
                  slidesPerView: 2,
                  spaceBetween: 24,
                },
            }
       }
    },
} 