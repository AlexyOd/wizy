export default class tabs
{
    constructor(selector, options) {
        this.domElement = document.querySelector(selector)
        if (!this.domElement) return
        this.cache(options)
        this.events()
        this.init()
    }

    cache(options) {
        this.settings = {
            ...this.defaults,
            ...options
        }
        this.$tabs = this.domElement.querySelectorAll(this.settings.tabItems)
        this.tabsContainer = document.querySelector(this.domElement.dataset.tabTarget)
    }

    events() {
        this.$tabs.forEach($tab => {
            $tab.addEventListener('click', this.handleClick.bind(this))
        });
    }

    get defaults () {
        return {
            tabItems: '.tabs-item',
            tabContent: '.projects-tiles__item',
            class: {
                activeTab: 'tabs-item-active',
                hiddeContent: 'hide'
            }
        }
    }

    get activeTab () {
        let activeTab = null
        const active = this.settings.class.activeTab
        this.$tabs.forEach($tab => {
            if ($tab.classList.contains(active)) {
                activeTab = $tab
            }
        })
        return activeTab
    }
    
    set activeTab (activeTab) {
        const key = activeTab.dataset.tabKey
        const hide = this.settings.class.hiddeContent.replace('.', '')
        const activeClass = this.settings.class.activeTab
        this.domElement.querySelector('.'+activeClass).classList.remove(activeClass)
        activeTab.classList.add(activeClass)
        
        this.tabsContainer.querySelectorAll(this.settings.tabContent).forEach($tab => {
            $tab.classList.add(hide)
            if( !+key || key === $tab.dataset.tabKey) {
                $tab.classList.remove(hide)
            }
        })  
    }

    init() {
        this.activeTab = this.activeTab
    }

    handleClick(event) {
        const $tab = event.currentTarget
        this.activeTab = $tab
    }
}