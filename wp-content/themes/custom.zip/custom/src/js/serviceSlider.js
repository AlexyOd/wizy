import Swiper from 'swiper';
import { Navigation, Pagination, Controller, Scrollbar } from 'swiper/modules';

export default {
    init() {
        this.cache();
    },
    cache() {
        this.settings = {
            container: '.service__portfolio-swiper.swiper',
            navCont: '.service__portfolio-nav',
        }
        const $slider = document.querySelector(this.settings.container)
        if(!$slider) return
        this.$slider = new Swiper(this.settings.container, this.swiperOptions);
        

    },
    get swiperOptions() {
        return {
            modules: [Navigation, Pagination, Controller, Scrollbar],
            centeredSlides: false,
            
            slidesPerView: 'auto',
            spaceBetween: 16,

            grabCursor: true,
            keyboard: {
                enabled: true,
            },
            scrollbar: {
                el: this.settings.navCont,
                draggable: true,
            },
            navigation: true,
            pagination: {
                clickable: true,
            },

            
        }
    },

}