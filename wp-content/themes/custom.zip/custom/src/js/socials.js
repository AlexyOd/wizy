export default {
    init() {
        this.cache()
        this.events()
    },
    cache() {
        this.settings = {
            container: '.social__wind',
            button: '.social__button',
            close: '.social__close',
            active: 'active'
        }
        this.$container = document.querySelector(this.settings.container)
        this.$button = this.$container.querySelector(this.settings.button)
        this.$closes = this.$container.querySelector(this.settings.close)
    },
    events() {
        this.$button.addEventListener('click', this.open.bind(this))
        this.$closes.addEventListener('click', this.close.bind(this))
    },
    open() {
        this.$container.classList.add(this.settings.active)
    },
    close() {
        this.$container.classList.remove(this.settings.active)
    }
}