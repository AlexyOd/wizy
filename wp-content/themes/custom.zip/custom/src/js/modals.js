export default {
    init() {
        this.cache();
        this.events();
    },
    cache() {
        this.settings = {
            open: '.js_modal-open',
            close: '.js_modal-close',
            container: '.js-modal',
            wrapepr: ".wrapper",
            wind: '.modal__wind',
            active: 'is-active',
            blur: 'blure',
            menu: '.menu__content',
            menuHide: 'none'
        }

        this.$document = document
        this.$openBtns = document.querySelectorAll(this.settings.open);
        this.$closeBtns = document.querySelectorAll(this.settings.close);
        this.$wrapepr = document.querySelector(this.settings.wrapepr);
        this.$wind = document.querySelectorAll(this.settings.wind);
        this.$containers = document.querySelectorAll(this.settings.container);
        this.$menu = document.querySelector(this.settings.menu);

        this.$document.addEventListener('event.modal.open', this.handleModalEventOpen.bind(this));
        this.$document.addEventListener('event.modal.close', this.handleModalEventClose.bind(this));
    },
    events() {
        this.$openBtns.forEach($openBtn => {
            $openBtn.addEventListener('click', this.handleOpenClick.bind(this));
        });
        this.$closeBtns.forEach($closeBtn => {
            $closeBtn.addEventListener('click', this.handleCloseClick.bind(this));
        })
        this.$wind.forEach($wind => {
            $wind.addEventListener('click', e => e.stopPropagation() );
        })
        this.$containers.forEach($container => {
            $container.addEventListener('click', this.handleCloseClick.bind(this));
        })
    },
    handleOpenClick(event) {
        const $target = event.currentTarget;
        const {modalId} = $target.dataset; 
        this.openModal(modalId);
    },
    
    handleCloseClick(event) {
        event.preventDefault();
        const $target = event.currentTarget;
        const $parent = $target.closest(this.settings.container);
        this.closeModal($parent.id);
    },
    openModal(modalId) {
        const $modal = this.$document.querySelector(`#${modalId}`);
        $modal.classList.add(this.settings.active);
        this.$wrapepr.classList.add(this.settings.blur);
        this.$menu.classList.add(this.settings.menuHide);
        
    },
    closeModal(modalId) {
        const $modal = this.$document.querySelector(`#${modalId}`);
        $modal.classList.remove(this.settings.active);
        this.$wrapepr.classList.remove(this.settings.blur);
        this.$menu.classList.remove(this.settings.menuHide);
    },
    handleModalEventOpen(event) {
        this.openModal(event.detail);
    },

    handleModalEventClose(event) {
        this.$containers.forEach(form=>{ 
            this.closeModal(form.id);
        })
    }

}

// this.$document.trigger('event.modal.close')
//                 this.$document.trigger('event.modal.open', 'modal-form-success')