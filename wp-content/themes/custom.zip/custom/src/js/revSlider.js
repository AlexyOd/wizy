import Swiper from 'swiper';
import { Navigation, Pagination, Controller } from 'swiper/modules';

export default {

    init() {
        this.cache()
    },  

    cache() {
        this.settings = {
            container: '.rev__slider',
            navCont: '.rev__slider-nav',
        }
        const $slider = document.querySelector(this.settings.container)
        if(!$slider) return
        this.$navSlider = new Swiper(this.settings.navCont,this.nawSwiperOptions)
        this.$slider = new Swiper(this.settings.container, this.swiperOptions)
        this.$slider.controller.control = this.$navSlider
    },

    get swiperOptions () {
        return  {
            modules: [Navigation, Pagination, Controller],
            autoHeight: true,    
            navigation: {
                prevEl: '.rev__slider--prev',
                nextEl: '.rev__slider--next',
            },
            Thumbs: {
                swiper: this.$navSlider
            }
       }
    },

    get nawSwiperOptions () {
        return {
            autoHeight: true,    
            slidesPerView: 1,
       }
    },
} 