export default {
    init() {
        this.cache()
        this.events()
    },
    cache() {
        this.settings = {
            container : '.page-mark',
            list: '.page-mark__marks',
            item: '.page-mark__item',
            active: 'active',
            hover: 'hover',
            btn: '.page-mark__button'
        }
        this.$btns = document.querySelectorAll(this.settings.btn)
    },
    events() {
        this.$btns.forEach($btn => {
            $btn.addEventListener('click', this.handleClick.bind(this))
            $btn.addEventListener('mouseenter', this.handleEnter.bind(this));
            $btn.addEventListener('mouseleave', this.handleLeave.bind(this));
        })
    },
    handleEnter(event) {
        const $btn = event.currentTarget
        const $list = $btn.closest(this.settings.list)
        $list.classList.add(this.settings.hover)

    },
    handleLeave(event) {
        const $btn = event.currentTarget
        const $list = $btn.closest(this.settings.list)
        $list.classList.remove(this.settings.hover)
    },

    handleClick(event) {
        const $btn = event.currentTarget
        const $list = $btn.closest(this.settings.list)
        $list.querySelector('.'+this.settings.active).classList.remove(this.settings.active)
        $btn.closest(this.settings.item).classList.add(this.settings.active)
    }
}