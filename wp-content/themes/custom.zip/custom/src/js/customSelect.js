export default  {
    init() {
        this.cache();
        this.events();
    },

    cache() {
        this.settings = {
            container: '.custom-select',
            items: '.custom-select__item',
            input: '.custom-select__input input'
        }
        
        this.$items = document.querySelectorAll(this.settings.items);
        this.$inputs = document.querySelectorAll(this.settings.input);
    },

    events() {
        this.$items.forEach($item => {
            $item.addEventListener('click', this.handleClick.bind(this));
        });
    },
    handleClick(event) {
        const $target = event.currentTarget;
        const $parent =  $target.closest(this.settings.container)
        const $input = $parent.querySelector(this.settings.input);
        $input.value = $target.textContent.trim();
    },

    

}