import customDropdown from './customDropdown.js'
import hamburger from './hamburger.js'
import rangeSliders from './rengeSliders'
import revSlider from './revSlider.js'
import serviceSvider from './serviceSlider.js'
import blogSlider from './blogSlider.js'
import customSelect from './customSelect.js'
import calculateForm from './calculateForm.js'
import modal from './modals.js'
import social from './socials.js'
import tabs from './tabs.js'
import simpleForm from './simpleForm.js'
import dbtn from './dbtn.js'
import scrollTo from './scrollTo.js'
import faq from './faq.js'
import marks from './marks.js'

document.addEventListener('DOMContentLoaded', function() {
    // Ваш JavaScript-код здесь
    customDropdown.init()
    hamburger.init()
    customSelect.init()
    calculateForm.init()
    modal.init()
    social.init()
    marks.init()
    simpleForm.init()
    dbtn.init()
    faq.init()
    rangeSliders.init()
    blogSlider.init()
    serviceSvider.init()
    revSlider.init()
    
    new tabs('#projects-taps')
    new scrollTo('#srllToForm', {target: '.bform'})
});

/*

document.querySelector( '.wpcf7' ).addEventListener( 'wpcf7submit', function( event ) {
  alert( "Fire!" );
}, false );

*/