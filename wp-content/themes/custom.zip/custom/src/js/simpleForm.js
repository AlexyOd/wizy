import Validation from "./validate.js";


export default {
    init() {
        this.cache()
        this.events()
    },
    cache() {
        this.settings = {
            container: '.simpleForm',
        }
        this.$forms = document.querySelectorAll(this.settings.container)
        
        this.$document = document
    },
    events() {
        this.$forms.forEach($form => {
            $form.addEventListener('submit', this.handleSubmit.bind(this))
        });

    },
    handleSubmit(event) {
        event.preventDefault()
        const $form = event.target
        const formData = new FormData($form)
        const xhr = new XMLHttpRequest()
        const $validation = new Validation($form)
        const inputs = $form.querySelectorAll('input[type="text"]')
        $validation.clear();
        const validate = $validation.getValidate(inputs);
        xhr.open('POST', '/mail.php', true)
        xhr.send(formData)
        if(!validate) return
        const _this = this
        xhr.onreadystatechange = function () {
            $form.reset()
            console.log(xhr);
            if(xhr.readyState === 4 ) {
                if (xhr.status === 200) {
                    _this.doSuccess()
                }
                else {
                    _this.doError()
                }
            }
        }
    },
    doSuccess() {
        var event = new CustomEvent('event.modal.open', {
            detail: 'modal-form-success'
        });
        document.dispatchEvent(event);
    },
    doError() {
        var event = new CustomEvent('event.modal.open', {
            detail: 'modal-form-error'
        });
        document.dispatchEvent(event);
    }
    
} 