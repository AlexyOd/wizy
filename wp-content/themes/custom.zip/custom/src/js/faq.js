export default {
    init() {
        this.cache()
        this.events()
    },
    cache() {
        this.settings = {
            item: '.faq',
            btn: '.faq__top',
            active: 'active',
            content: '.faq__cont',
        }
        this.$items = document.querySelectorAll(this.settings.item)
    },
    events() {
        if(!this.$items) return
        this.$items.forEach($item => {
            const $btns = $item.querySelector(this.settings.btn)
            $btns.addEventListener('click', this.handleClick.bind(this))
        })
    },
    handleClick(event) {
        const $target = event.currentTarget
        const $item = $target.closest(this.settings.item)
        this.toggleActive($item)
    },
    toggleActive($item) {
        const active = $item.classList.toggle(this.settings.active)
        const $cont = $item.querySelector(this.settings.content)
        debugger
        if(active) {
            const height = $cont.querySelector('& > *').clientHeight
            $cont.style.height = height + 'px'
        } else {
            $cont.style.height = ''
        }
        
    }

}