import rangeSlider from './rengeSlider.js'
export default {
    init() {
        this.cache()
        this.start()
    },

    cache() {
        this.settings = {
            container: '.range-slider',
            slider: '.slider',
            sliderMinLabel: '.range-slider__min',
            sliderMaxLabel: '.range-slider__max',
            input: 'input',
        }

        
        this.$containers = document.querySelectorAll(this.settings.container)
    },

    start() {
        this.$containers.forEach($container => {
            const $sliderMinLabel = $container.querySelector(this.settings.sliderMinLabel)
            const $sliderMaxLabel = $container.querySelector(this.settings.sliderMaxLabel)
            const $slider = $container.querySelector(this.settings.slider)
            const {min,max,unit, value} = $slider.dataset
            const $input = $container.querySelector(this.settings.input)
            $input.value = value

            new rangeSlider({$slider, min,max, value, $input})
            $sliderMinLabel.innerHTML = min + (unit || '')
            $sliderMaxLabel.innerHTML = max + (unit || '')
        });
    },
}