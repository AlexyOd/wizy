export default class scrollTo {
    constructor(selector, options) {
        this.domElement = document.querySelector(selector)
        if (!this.domElement) return
        this.cache(options)
        this.events()
    }

    cache(options) {
        this.settings = {
            ...this.defaults,
            ...options
        }
        this.$anchor = this.domElement
        this.$target = document.querySelector(this.settings.target)
    }

    events() {
        this.$anchor.addEventListener('click', this.handleClick.bind(this))
    }

    get defaults() {
        return {
            trget: ''
        }
    }

    handleClick() {
        let top = 0 
        if(this.$target) {
            top = this.$target.offsetTop
        }
        window.scrollTo({
            top,
            behavior: 'smooth'
        })
    }
}