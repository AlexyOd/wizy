import Validation from "./validate.js";
export default {
    init() {
        this.cache();
        this.events();
    },
    cache() {
        this.settings = {
            container: '#popup-calculate',
            btn: '.js-calculate-form_submit',
            form: '.js-calculate-form',
            success: '.js-calculate-form-success',
            error: '.js-calculate-form-error',
            close: '.js_modal-close',
            hidden: 'js-hidden',
            errors: {
                noempty: {
                    'ru-RU': 'Заполните поле',
                    'uk': 'Заповніть поле'
                },
                format: {
                    'ru-RU': 'неправильний формат',
                    'uk': 'неправильний формат'
                },
                selectItem: {
                    'ru-RU': 'Выберите из списка',
                    'uk': 'Виберіть зі списку'
                }
            },
            validate: {
                phone: ['noempty','format'],
                name: ['noempty'],
                city: ['selectItem']
            }
        }

        this.$container = document.querySelector(this.settings.container)
        this.$form = this.$container.querySelector(this.settings.form)
        this.$btn = this.$container.querySelector(this.settings.btn);
        this.$success = this.$container.querySelector(this.settings.success)
        this.$error = this.$container.querySelector(this.settings.error)
        this.$close = this.$container.querySelector(this.settings.close)
        this.$validation = new Validation(this.settings.form)

    },
    events() {
        this.$btn.addEventListener('click', this.submit.bind(this));
        this.$close.addEventListener('click', this.resetForm.bind(this));
    },


    submit(event) {
        const $form = this.$form
        const xhr = new XMLHttpRequest();
        const formData = new FormData($form);
        const _this = this
        this.$validation.clear();
        const validate = this.getValidate()
        if(!validate) return
        xhr.open('POST', '/mail.php', true);
        xhr.onreadystatechange = function () {
            const hidden = _this.settings.hidden
            _this.$form.reset()
            _this.$form.classList.add(hidden)
            _this.$btn.classList.add(hidden)
            if(xhr.readyState === 4) {
                if (xhr.status === 200) {
                    _this.$error.classList.add(hidden);
                    _this.$success.classList.remove(hidden);
                } else {
                    _this.$success.classList.add(hidden);
                    _this.$error.classList.remove(hidden); 
                }
            }
        };

        xhr.send(formData);
    }, 
    getValidate() {
        const textInputs = this.$form.querySelectorAll('input[type="text"]');
        let isvalid = true
        textInputs.forEach(input=>{
            isvalid = this.validate(input)
        })

        return isvalid
    },
    validate(input) {
        let isvalid = true
        for (const fn of this.settings.validate[input.name]) {
            if (!this[fn]) continue;
            
            const validate = this[fn](input);
            if (!validate) {
                isvalid = false;
                this.setError(input, fn);
                break; // Выходим из цикла, так как условие не выполнилось
            }
        }
        return isvalid
    },
    setError(input,err) {
        const lang = [this.getLeng()]
        const message = this.settings.errors[err][lang]
        this.$validation.push({input,message})
    },
    noempty(input) {
        return !!input.value.length
    },
    selectItem(input) {
        return this.noempty(input)
    },
    format(input) {
        const phoneRegex = /^(\+\d{12}|\d{10})$/;
        return phoneRegex.test(input.value); 
    },

    resetForm() {
        this.$validation.clear();
        this.$form.classList.remove(this.settings.hidden)
        this.$btn.classList.remove(this.settings.hidden)
        this.$success.classList.add(this.settings.hidden)
        this.$error.classList.add(this.settings.hidden)
        this.$form.reset()
    },

    getLeng() {
        return document.documentElement.lang || navigator.language || navigator.userLanguage || 'en';
    }

}

