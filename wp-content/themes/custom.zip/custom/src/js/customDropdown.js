
export default {
    init() {
        this.cache()
        this.events()
    },
    cache() {
        this.settings = {
            container: '.custom-dropdown',
            list: '.custom-dropdown__list',
            btn: '.custom-dropdown__btn',
            active: 'active'
        }
        this.$btns = document.querySelectorAll(this.settings.btn)
        this.$document = document
    },
    events() {
        this.$btns.forEach($btn => {
            $btn.addEventListener('click', this.handleClick.bind(this))
        });

        document.addEventListener('click', this.handleClickOutside.bind(this));        
    },
    handleClick(event) { 
        const $btn = event.currentTarget
        const $parent = this.parents($btn, this.settings.container)
        this.removeActiveDropDown($parent);
        if(!$parent) return
        $parent.classList.toggle(this.settings.active)
    },
    removeActiveDropDown($current) {
        const {container,active} = this.settings
        const $activeDropDown = document.querySelector(container + '.' + active)
        if($activeDropDown && $activeDropDown  != $current) $activeDropDown.classList.remove(active)
    },

    parents($element, className) {
        className =  className.replaceAll('.','')
        let $parent = $element.parentElement;
        while ($parent && !$parent.classList.contains(className)) {
          $parent = $parent.parentElement;
        }
        return $parent;
    },
    handleClickOutside(event) {
        // Проверяем, был ли клик вне контейнера выпадающего списка
        const $target = event.target;
        const isOutsideDropdown = !this.parents($target, this.settings.container);

        // Если клик был вне выпадающего списка, скрываем его
        if (isOutsideDropdown) {
            const $activeDropDown = document.querySelector(`${this.settings.container}.${this.settings.active}`);
            if ($activeDropDown) {
                $activeDropDown.classList.remove(this.settings.active);
            }
        }
    }
}