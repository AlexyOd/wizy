export default class Validation {
    constructor(element, options) {
        this.$domElement = element
        this.cache(options)
    }

    cache(options) {
        this.settings = {
            ...this.defaults,
            ...options
        }
    }

    get defaults () {
        return {
            container: '.custom-input',
            errClass: 'custom-error',
            inputErrorClass: 'custom-input__error',
            customSelect: '.custom-select__input ',
            errors: {
                noempty: {
                    'ru-RU': 'Заполните поле',
                    'uk': 'Заповніть поле'
                },
                telFormat: {
                    'ru-RU': 'неправильний формат',
                    'uk': 'неправильний формат'
                },
                emailFormat: {
                    'ru-RU': 'неправильний формат',
                    'uk': 'неправильний формат'
                },
                selectItem: {
                    'ru-RU': 'Выберите из списка',
                    'uk': 'Виберіть зі списку'
                }
            },
            validate: {
                phone: ['noempty','telFormat'],
                name: ['noempty'],
                city: ['selectItem'],
                email: ['noempty','emailFormat']
            }
        }
    }

    push(data) {
        const {input,message} = data
        const tclass = this.settings.errClass
        const spanHTML = '<span class="'+tclass+'">'+message+'</span>';
        input.insertAdjacentHTML('afterend', spanHTML);
        const container = input.closest(this.settings.container)
        container.classList.add(this.settings.inputErrorClass)
        const customSelect =  container.closest(this.settings.customSelect)
        if(customSelect) customSelect.classList.add(this.settings.inputErrorClass)
    }

    clear() {
        const inputErrorSelector = '.'+this.settings.inputErrorClass
        const errelector = '.'+this.settings.errClass
        this.$domElement.querySelectorAll(inputErrorSelector).forEach($input => {
            $input.classList.remove(this.settings.inputErrorClass)
        });
        this.$domElement.querySelectorAll(errelector).forEach($errorElement => {
            $errorElement.remove()
        });
    }

    getValidate(inputs) {
        if(!inputs) return
        let isvalid = true
        inputs.forEach(input=>{
            const validate = this.validate(input)
            isvalid = isvalid && validate
        })

        return isvalid
    }

    validate(input) {
        let isvalid = true
        for (const fn of this.settings.validate[input.name]) {
            if (!this[fn]) continue;
            
            const validate = this[fn](input);
            if (!validate) {
                isvalid = false;
                this.setError(input, fn);
                break;
            }
        }
        return isvalid
    }

    setError(input,err) {
        const lang = [this.getLeng()]
        const message = this.settings.errors[err][lang]
        this.push({input,message})
    }

    noempty(input) {
        return !!input.value.length
    }

    selectItem(input) {
        return this.noempty(input)
    }

    telFormat(input) {
        const phoneRegex = /^(\+\d{12}|\d{10})$/;
        return phoneRegex.test(input.value); 
    }
    emailFormat(input) {
        const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return emailRegex.test(input.value);
    }

    getLeng() {
        return document.documentElement.lang || navigator.language || navigator.userLanguage || 'en';
    }
    
    
}