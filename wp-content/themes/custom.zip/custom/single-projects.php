<div class="wrapper">
    <?php
    $harakteristiki = get_field('harakteristiki');
    $largePoster = get_field('largePoster');
    $name = get_the_title();
    $location = get_field('card_location');
    $status = get_field('status');
    $zadachi_poster = get_field('zadachi_poster');
    $zadachi = get_field('zadachi');
    $etapi_poster = get_field('etapi_poster');
    $etapi = get_field('etapi');

    $res_title  = get_field('res_title');
    $res_descr  = get_field('res_descr');
    $res_poster  = get_field('res_poster');
    $res_poster_left  = get_field('res_poster_left');
    $res_poster_right  = get_field('res_poster_right');

    $questions = get_field('questions');

    $email = get_theme_mod('email');
    $phone = get_theme_mod('phone');

    function isImageOrVideo($url) {
        // Получаем информацию о изображении
        $imageInfo = @getimagesize($url);
    
        // Проверяем, является ли ссылка изображением
        if ($imageInfo !== false) {
            return 'image';
        }
    
        // Если не изображение, проверяем расширение файла для видео
        $videoExtensions = array('mp4', 'webm', 'ogg'); // Добавьте расширения видео, которые вам интересны
    
        $fileExtension = pathinfo($url, PATHINFO_EXTENSION);
    
        if (in_array(strtolower($fileExtension), $videoExtensions)) {
            return 'video';
        }
    
        // Если не изображение и не видео, возвращаем 'other'
        return 'other';
    }



    get_header(); ?>
    <main class="main portfolio-single">
        <?php
            $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
            if (file_exists($breadcrumbs)) {
                $lang = pll_current_language() == 'ru' ? '/ru' : '';
                $link = get_site_url().$lang;
                $parents = array(
                    array(
                        'link' => $link.'/projects/',
                        'name' => pll__('projects_title')
                    ),
                );
                include $breadcrumbs;
            } else {
                echo 'Файл breadcrumbs.php не найден';
            }
        ?>

        <section class="portfolio-single__top">
            <div class="container">
                <p class="portfolio-single__name">
                    <?php
                        echo $name
                    ?>
                </p>
                <div class="row">
                    <div class="col-12 col-lg-5 d-flex align-items-center">
                        <div class="portfolio-single__harakteristiki">
                            <p class="portfolio-single__harakteristiki-title">
                                <?php
                                    echo pll__('projects_about')
                                ?>:
                            </p>
                            <p class="portfolio-single__harakteristiki-location">
                                <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_176_5735)">
                                        <path d="M8.0002 1.38867C6.61585 1.38983 5.2882 1.93875 4.30723 2.91556C3.32626 3.89236 2.77169 5.21767 2.76465 6.60201C2.76465 8.67756 3.92909 10.4153 4.78243 11.682L4.93798 11.9131C5.78699 13.1436 6.69779 14.3303 7.66687 15.4687L8.00465 15.8642L8.34243 15.4687C9.31138 14.3302 10.2222 13.1435 11.0713 11.9131L11.2269 11.6776C12.0758 10.4109 13.2402 8.67756 13.2402 6.60201C13.2332 5.2169 12.678 3.89092 11.696 2.91399C10.7141 1.93706 9.38533 1.38865 8.0002 1.38867ZM8.0002 8.94423C7.42356 8.94423 6.85987 8.77323 6.38041 8.45287C5.90095 8.1325 5.52725 7.67716 5.30658 7.14441C5.08591 6.61166 5.02817 6.02544 5.14067 5.45988C5.25317 4.89431 5.53085 4.37481 5.9386 3.96706C6.34634 3.55932 6.86585 3.28164 7.43141 3.16914C7.99697 3.05664 8.58319 3.11438 9.11594 3.33505C9.64869 3.55572 10.104 3.92942 10.4244 4.40888C10.7448 4.88834 10.9158 5.45203 10.9158 6.02867C10.9158 6.80193 10.6086 7.54351 10.0618 8.09028C9.51504 8.63705 8.77346 8.94423 8.0002 8.94423Z" fill="#F35C26"/>
                                        <path d="M7.99957 7.68665C8.91514 7.68665 9.65735 6.94444 9.65735 6.02887C9.65735 5.11331 8.91514 4.37109 7.99957 4.37109C7.08401 4.37109 6.3418 5.11331 6.3418 6.02887C6.3418 6.94444 7.08401 7.68665 7.99957 7.68665Z" fill="#F35C26"/>
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_176_5735">
                                            <rect width="16" height="16" fill="white" transform="translate(0 0.5)"/>
                                        </clipPath>
                                    </defs>
                                </svg>

                                <?php
                                    echo $location
                                ?>
                            </p>
                            <div class="portfolio-single__harakteristiki-content">

                                <?php
                                    if (!empty($harakteristiki)) {
                                        foreach ($harakteristiki as $har) {
                                            $title = $har['title'];
                                            $value = $har['value'];
                                            $unit = $har['unit'];
                                ?>
                                    <div class="portfolio-single__harakteristiki-item">
                                        <div class="portfolio-single__harakteristiki-item-title">
                                            <?php
                                                echo $title
                                            ?>
                                        </div>
                                        <div class="portfolio-single__harakteristiki-item-value">
                                            <?php
                                                echo $value . ' ' . $unit;
                                            ?>
                                        </div>
                                    </div>
                                <?php
                                        }
                                    }
                                ?>
                                <?php
                                    if (!empty($status)) {
                                     
                                ?>
                                    <div class="portfolio-single__harakteristiki-item">
                                        <div class="portfolio-single__harakteristiki-item-title">
                                            <?php
                                                echo pll__('status')
                                            ?>
                                        </div>
                                        <div class="portfolio-single__harakteristiki-item-value">
                                            <?php
                                                echo $status
                                            ?>
                                        </div>
                                    </div>
                                <?php
                                    }
                                ?>
                                

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-7 d-flex align-items-center">
                        <img class="portfolio-single__lposter" src="<?php echo $largePoster ?>" alt="<?php echo $name ?>">

                    </div>
                </div>
            </div>
        </section>
        <section class="portfolio-single__task">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <p class="section__title">
                            <?php
                                echo pll__('zadachi_title')
                            ?>
                        </p>

                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <img class="portfolio-single__lposter" src="<?php echo $zadachi_poster ?>" alt="<?php echo pll__('zadachi_title')?>">
                    </div>
                    <div class="col-12 col-lg-5 offset-lg-1">
                        <ul class="portfolio-single__task-list">
                            <?php
                                foreach ($zadachi as $zad) {
                                    $title = $zad['title'];
                                    $descr = $zad['descr'];
                            ?>
                                <li class="portfolio-single__task-item">
                                    <p class="portfolio-single__task-item-title">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M21.7959 7.54597L9.7959 19.546C9.69138 19.6509 9.56719 19.7341 9.43044 19.7909C9.2937 19.8476 9.14709 19.8769 8.99902 19.8769C8.85096 19.8769 8.70435 19.8476 8.5676 19.7909C8.43085 19.7341 8.30666 19.6509 8.20215 19.546L2.95215 14.296C2.8475 14.1913 2.76449 14.0671 2.70785 13.9304C2.65122 13.7936 2.62207 13.6471 2.62207 13.4991C2.62207 13.3511 2.65122 13.2046 2.70785 13.0678C2.76449 12.9311 2.8475 12.8069 2.95215 12.7022C3.05679 12.5976 3.18103 12.5146 3.31776 12.4579C3.45448 12.4013 3.60103 12.3721 3.74902 12.3721C3.89702 12.3721 4.04356 12.4013 4.18029 12.4579C4.31702 12.5146 4.44125 12.5976 4.5459 12.7022L8.99996 17.1563L20.204 5.9541C20.4154 5.74276 20.702 5.62402 21.0009 5.62402C21.2998 5.62402 21.5864 5.74276 21.7978 5.9541C22.0091 6.16544 22.1278 6.45209 22.1278 6.75098C22.1278 7.04986 22.0091 7.33651 21.7978 7.54785L21.7959 7.54597Z" fill="#F35C26"/>
                                        </svg>
                                        <?php
                                            echo $title
                                        ?>
                                    </p>
                                    <p class="portfolio-single__task-item-descr">
                                        <?php
                                            echo $descr
                                        ?>
                                    </p>
                                </li>

                            <?php
                                }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <?php
            if (isset($etapi)) {
        ?>
            <section class="portfolio-single__etapi">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <p class="section__title">
                                <?php
                                    echo pll__('etapi_title')
                                ?>
                            </p>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-5">
                            <ul class="portfolio-single__task-list">
                                <?php
                                    foreach ($etapi as $index => $zad) {
                                        $title = $zad['title'];
                                        $descr = $zad['descr'];
                                ?>
                                    <li class="portfolio-single__task-item">
                                        <p class="portfolio-single__task-item-title">
                                        <span><?php echo $index + 1 ?>.</span>
                                            <?php
                                                echo $title
                                            ?>
                                        </p>
                                        <p class="portfolio-single__task-item-descr">
                                            <?php
                                                echo $descr
                                            ?>
                                        </p>
                                    </li>

                                <?php
                                    }
                                ?>
                            </ul>
                        </div>
                        <div class="col-12 col-lg-6 offset-lg-1">
                            <img class="portfolio-single__lposter" src="<?php echo $etapi_poster ?>" alt="<?php echo pll__('etapi_title')?>">
                        </div>
                    </div>
            </section>
        <?php
            }
        ?>

        <section class="portfolio-single__result">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <p class="section__title">
                            <?php
                                echo $res_title
                            ?>
                        </p>
                    </div>
                    <div class="col-12 col-md-6">
                        <p class="section__descr  portfolio-single__result-descr">
                            <?php
                                echo $res_descr
                            ?>
                        </p>
                    </div>
                </div>
                <div class="row portfolio-single__result-cont">
                    <?php
                        if(isset($res_poster)){
                    ?>
                    <div class="col-12">
                        <?php
                            $type = isImageOrVideo($res_poster);
                            if($type == 'image'){
                                
                        ?>
                        <img src="<?php echo $res_poster ?>" alt=" <?php echo $res_title ?>">
                        
                        <?php
                            } else if($type == 'video') {
                             
                        ?>
                            <video class="main-top__video" autoplay muted loop>
                                <source src="<?php echo $res_poster ?>" type="video/mp4">
                            </video>
                        <?php
                            }
                        ?>
                    </div>
                    <?php
                        }
                    ?>
                </div>

                <div class="row">
                    <?php
                        if (isset($res_poster_left)) {
                            $plClass = isset($res_poster_right) ? ' col-lg-6' : '';
                    ?>
                    <div class="col-12<?php echo $plClass ?>">
                        <div class="portfolio-single__result-posters">
                            <?php
                                foreach ($res_poster_left as $index => $poster) {   
                                    $poster = $poster['poster'];
                                    $alt = 'poster-'.($index + 1);
                            ?>
                                <div class="portfolio-single__result-poster">
                                    <img src="<?php echo $poster ?>" alt="<?php echo $alt ?>">
                                </div>
                            <?php
                                }
                            ?>
                        </div>
                    </div>
                    <?php
                        }
                    ?>
                     <?php
                        if (isset($res_poster_right)) {
                            $plClass = isset($res_poster_left) ? ' col-lg-6' : '';
                    ?>
                    <div class="col-12<?php echo $plClass ?>">
                        <div class="portfolio-single__result-posters">
                            <?php
                                foreach ($res_poster_right as $index => $poster) {   
                                    $poster = $poster['poster'];
                                    $alt = 'poster-right'.($index + 1);
                            ?>
                                <div class="portfolio-single__result-poster">
                                    <img src="<?php echo $poster ?>" alt="<?php echo $alt ?>">
                                </div>
                            <?php
                                }
                            ?>
                        </div>
                    </div>
                    <?php
                        }
                    ?>


                </div>
        </section>

        <?php
            if (isset($questions)) {
             
        ?>
        <section class="portfolio-single__faq">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <p class="section__title" style="text-align: center">
                            <?php
                                echo pll__('faq_title')
                            ?>
                        </p>
                    </div>
                </div>
                <?php
                    
                    foreach ($questions as $question) {
                    $title = $question['title'];
                    $descr = $question['descr']; 
                ?>

                
                    <div class="row">
                        <div class="col-12 col-lg-8 offset-lg-2">
                            <?php
                                $faqpage = get_template_directory() . '/parts/faq.php';
                                if (file_exists($faqpage)) {
                                    
                                    $faq = array(
                                        'title' => $title,
                                        'descr' => $descr
                                    );
                                    include $faqpage;
                                } else {
                                    echo 'Файл faq.php не найден';
                                }
                            ?>
                        </div>
                    </div>
                <?php
                    }
                ?>
            </div>
        </section>
        <?php
            }
        ?>

        <section class="portfolio-bform">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-5 d-flex align-items-center">
                        <div class="bform__cont">
                            <div class="section__title">
                                <?php
                                    echo pll__('faq_form_title')
                                ?>
                            </div>
                           
                            <p class="portfolio-bform__text"> <?php echo $email ?> <p>
                            <p class="portfolio-bform__text"> <?php echo $phone ?> <p>
                        </div>
                    </div>
                    <div class="col-12 offset-lg-1 col-lg-6 d-flex align-items-center">
                        <div style="width: 100%">
                            <p class="portfolio-bform__simp-p">
                                <?php
                                    echo pll__('faq_form_descr')
                                ?>
                            </p>
                            <?php
                                $simpleForm = get_template_directory() . '/parts/simpleForm.php';
                                if (file_exists($simpleForm)) {
                                    $bform = array(
                                        array(
                                            'acf_fc_layout' => 'input',
                                            'name' => 'email',
                                            'placeholder' => pll__('form_emael_placeholder')
                                        ),
                                    );
                                    include $simpleForm;
                                } else {
                                    echo 'Файл simpleForm.php не найден';
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
       
    </main>
</div>
<?php get_footer(); ?>

