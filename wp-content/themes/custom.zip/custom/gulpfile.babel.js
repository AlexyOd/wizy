const { src, dest, watch, series, parallel } = require('gulp');
const yargs = require('yargs');
const sass = require('gulp-sass')(require('sass'));
const cleanCss = require('gulp-clean-css');
const gulpif = require('gulp-if');
const postcss = require('gulp-postcss');
const sourcemaps = require('gulp-sourcemaps');
const autoprefixer = require('autoprefixer');
const imagemin = require('gulp-imagemin');
const webpack = require('webpack-stream');
const named = require('vinyl-named');
const browserSync = require('browser-sync');

const PRODUCTION = yargs.argv.prod;

const server = browserSync.create();

const reload = function(done) {
  server.reload();
  done();
};

exports.styles = function() {
  return src(['src/scss/main.scss'])
    .pipe(gulpif(!PRODUCTION, sourcemaps.init()))
    .pipe(sass().on('error', sass.logError))
    .pipe(gulpif(PRODUCTION, postcss([autoprefixer])))
    .pipe(gulpif(PRODUCTION, cleanCss({ compatibility: 'ie8' })))
    .pipe(gulpif(!PRODUCTION, sourcemaps.write()))
    .pipe(dest('dist/css'))
    .pipe(server.stream());
};

exports.images = function() {
  return src('src/img/**/*.{jpg,jpeg,png,svg,gif}')
    .pipe(gulpif(PRODUCTION, imagemin()))
    .pipe(dest('dist/img'));
};

exports.watchForChanges = function() {
  // Отслеживание изменений внутри src
  watch('src/**/*', series(exports.styles, exports.images, exports.scripts, reload));
  watch("**/*.php", reload);
};

exports.scripts = function() {
  return src('src/js/common.js')
    .pipe(named())
    .pipe(webpack({
      module: {
        rules: [
          {
            test: /\.js$/,
            use: {
              loader: 'babel-loader',
              options: {
                presets: ['@babel/preset-env']
              }
            }
          }
        ]
      },
      mode: PRODUCTION ? 'production' : 'development',
      devtool: !PRODUCTION ? 'inline-source-map' : false,
      output: {
        filename: '[name].js'
      },
    }))
    .pipe(dest('dist/js'));
};

exports.serve = function(done) {
  server.init({
    proxy: "http://agro"
  });
  done();
};

exports.dev = series(parallel(exports.styles, exports.images, exports.scripts), exports.serve, exports.watchForChanges);

exports.build = series(parallel(exports.styles, exports.images, exports.scripts));

exports.default = exports.dev;
