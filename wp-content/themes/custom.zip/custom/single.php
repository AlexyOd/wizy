<?php
get_header() ; the_post();?>

<?php setPostViews(get_the_ID()); ?>

<section class="blog-post">

</section>

<?php get_footer() ;?>