<div class="wrapper">
  <?php
    $date = get_field('date');

    $time_to_read = get_field('time_to_read');
    $blog_mark = get_field('blog_mark');
    $pohozhie = get_field('pohozhie');

    $title = get_the_title();
  get_header(); ?>
    <main class="main blog">
        <?php
            $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
            if (file_exists($breadcrumbs)) {
                $lang = pll_current_language() == 'ru' ? '/ru' : '';
                $link = get_site_url().$lang;
                $parents = array(
                    array(
                        'link' => $link.'/blog/',
                        'name' => pll__('plog_page')
                    ),
                );
                include $breadcrumbs;
            } else {
                echo 'Файл breadcrumbs.php не найден';
            }
        ?>
        <div class="container">
            <div class="row blog__top">
                <div class="col-12 col-md-6 col-lg-4 offset-lg-2 d-flex align-items-center">
                        <?php
                            $categories = get_the_category();
                            if (!empty($categories)) {
                                $category_slugs = array();
                                foreach ($categories as $category) {
                                    $category_slugs[] = $category->slug;
                                    $category_names[] = $category->name;
                                }
                                $category_link = '/blog/?category=' . implode(',', $category_slugs);
                                echo '<a class="blog__category" href="' . esc_url($category_link) . '">' . implode(', ', $category_names) . '</a>';
                            }
                        ?>
                </div>
                <div class="col-12 col-md-6 col-lg-4 d-flex align-items-center justify-content-end">
                    <?php
                        echo $date;
                    ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4 offset-lg-2 d-flex align-items-center">
                    <p>
                        <?php
                            echo $time_to_read;
                        ?>
                    </p>
                </div>
                <div class="col-12 col-md-6 col-lg-4 d-flex align-items-center justify-content-end">
                    <p>
                        <?php
                            echo $blog_mark;
                        ?>
                    </p>
                    <svg class="icon" width="24" height="24"><use href="#icon-star-fill"></use></svg>
                    
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-8 offset-lg-2">
                    <h1 class="blog__name"><?php echo $title; ?></h1>
                </div>
            </div>
        </div>
        <div class="container blog__cont">
                <?php

                    function wrapTextInParagraphs($content) {
                         // Разбиваем текст на строки
                            $lines = explode("\n", $content);
                            
                            // Результирующая строка
                            $result = '';

                            // Перебираем строки
                            foreach ($lines as $line) {
                                // Если строка не содержит тегов, оборачиваем в тег <p>
                                if (strip_tags($line) === $line) {
                                    // Если строка не пустая, добавляем в результат
                                    if (!empty(trim($line))) {
                                        $result .= "<p>$line</p>\n";
                                    }
                                } else {
                                    // Иначе добавляем строку как есть
                                    if(preg_match('/<img[^>]+>\s*<img[^>]+>/', $line)) {
                                        $result .= "<div class='blog__images'>$line</div>\n";    
                                    } else {
                                        $result .= "$line\n";
                                    }
                                }
                            }

                            return $result;
                    }

                    // Исходный текст
                    $content = get_the_content();



                    function processContent($content) {
                        // Разбиваем текст на строки
                        $lines = explode("\n", $content);
                        
                        // Результирующая строка
                        $result = '';
                        
                        // Флаг для отслеживания открытого блока с изображением
                        $imgBlockOpen = false;

                        // Перебираем строки
                        foreach ($lines as $index => $line) {
                            $row = '<div class ="row">';
                            $col = '';
                                
                            if(!empty(trim($line))) {   
                                
                                
                                if (preg_match('/<img/', $line)) {
                                    $class = ' blog__image';
                                    $col = '<div class ="col-12 d-flex justify-content-center'.$class.'">'.$line.'</div>'; 
                                } elseif (preg_match('/<p>|<h[1-6]>/', $line)) {
                                    $class = ' col-lg-8 offset-lg-2 blog__text';
                                    $col = '<div class ="col-12'.$class.'">'.$line.'</div>'; 
                                } 
                                else {
                                    $col = '<div class ="col-12'.$class.'">'.$line.'</div>'; 
                                }
                                $class = '';
                                
                                $result=$result . $row.$col.'</div>';
                            }
                        }
                        return $result;
                    }

                    // Вызываем функцию
                    $wrappedContent = wrapTextInParagraphs($content);

                    // Вызываем функцию
                    $processedContent = processContent($wrappedContent);

                    // Выводим результат
                    echo $processedContent;

                ?>
        </div>
        <div class="container blog__footer">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4 offset-lg-2 d-flex align-items-center">
                    <?php
                        $lang = pll_current_language() == 'ru' ? '/ru' : '';
                        $link = get_site_url().$lang.'/blog';
                    ?>
                <a class="button button_size_middle button_color_black" href="<?php echo $link; ?>"><?php echo pll__('back_to_blogs');?></a>
                </div>
                <div class="col-12 col-md-6 col-lg-4 d-flex align-items-center justify-content-end">

                    <div class="page-mark">
                        <p><?php echo pll__('mark_this_blog');?></p>

                        <ul class="page-mark__marks">
                            <li class = "page-mark__item active">
                                <button class="page-mark__button button button_type_icon">
                                    <svg class="icon icon-star" width="24" height="24">
                                        <use href="#icon-star"></use>
                                    </svg>
                                </button>
                            </li>
                            <li class = "page-mark__item">
                                <button class="page-mark__button button button_type_icon">
                                    <svg class="icon icon-star" width="24" height="24">
                                        <use href="#icon-star"></use>
                                    </svg>
                                </button>
                            </li>
                            <li class = "page-mark__item">
                                <button class="page-mark__button button button_type_icon">
                                    <svg class="icon icon-star" width="24" height="24">
                                        <use href="#icon-star"></use>
                                    </svg>
                                </button>
                            </li>
                            <li class = "page-mark__item">
                                <button class="page-mark__button button button_type_icon">
                                    <svg class="icon icon-star" width="24" height="24">
                                        <use href="#icon-star"></use>
                                    </svg>
                                </button>
                            </li>
                            <li class = "page-mark__item">
                                <button class="page-mark__button button button_type_icon">
                                    <svg class="icon icon-star" width="24" height="24">
                                        <use href="#icon-star"></use>
                                    </svg>
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <section>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <p class="blog__name">
                            <?php
                                echo pll__('similar_blog');
                            ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="blog__swiper swiper">
                            <div class="swiper-wrapper">
                                <?php
                                foreach ($pohozhie as $similar) {
                                    $item  = $similar['novost'];
                                    $id = $item->ID;
                                    $categories = get_the_category($item->ID);
                                    $blog_card = get_template_directory() . '/parts/blog_card.php';
                                    if (file_exists($blog_card)) {
                                        $card = array(
                                            'title' => $item->post_title,
                                            'categoryName' => $categories[0]->cat_name,
                                            'date' =>  get_the_date('d F, Y', $id),
                                            'shortDescr' => get_field('korotkoe_opisanie', $id),
                                            'blog_mark' =>get_field('blog_mark', $id),
                                            'poster' => get_field('poster', $id),
                                            'time_to_read' =>  get_field('time_to_read', $id),
                                            'link' =>  get_permalink($id)
                                        );
                                        include $blog_card;
                                    } else {
                                        echo 'Файл blog_card.php не найден';
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
  </div>

  <?php get_footer(); ?>
