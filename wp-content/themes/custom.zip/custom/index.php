<div class="wrapper">
  <?php
  /*Template Name: Главная страница*/
  get_header(); ?>
    <main class="main">
      <?php
        $main_top = get_template_directory() . '/parts/main_top.php';
        if (file_exists($main_top)) {
          include $main_top;
        } else {
          echo 'Файл main_top.php не найден';
        }
      ?>

      <?php
        $expphp = get_template_directory() . '/parts/exp.php';
        if (file_exists($expphp)) {
          include $expphp;
        } else {
          echo 'Файл exp.php не найден';
        }
      ?>
      <?php
        $uget = get_template_directory() . '/parts/uget.php';
        if (file_exists($uget)) {
          include $uget;
        } else {
          echo 'Файл uget.php не найден';
        }
      ?>

      <?php
        $block_about = get_template_directory() . '/parts/block_about.php';
        if (file_exists($block_about)) {
          include $block_about;
        } else {
          echo 'Файл block_about.php не найден';
        }
      ?>

      <?php
        $directions = get_template_directory() . '/parts/directions.php';
        if (file_exists($directions)) {
          include $directions;
        } else {
          echo 'Файл directions.php не найден';
        }
      ?>
      <?php
        $projects = get_template_directory() . '/parts/projects.php';
        if (file_exists($projects)) {
          include $projects;
        } else {
          echo 'Файл projects.php не найден';
        }
      ?>

      <?php
        $rev = get_template_directory() . '/parts/rev.php';
        if (file_exists($rev)) {
          include $rev;
        } else {
          echo 'Файл rev.php не найден';
        }
      ?>

      <?php
        $bottom_form = get_template_directory() . '/parts/bottom_form.php';
        if (file_exists($bottom_form)) {
          $bottomForm = array(
            'title' => get_field('bform_title'),
            'subtitle' => get_field('bform_subtitle'),
            'text' =>  get_field('bform_text'),
            '$form' => get_field('bform')
          );
          include $bottom_form;
        } else {
          echo 'Файл bottom_form.php не найден';
        }
      ?>
    </main>
  </div>

  <?php get_footer(); ?>
