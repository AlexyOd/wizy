<div class="swiper-slide">
    <?php if($card['link']) : ?>
        
    <a href="<?php echo $card['link']; ?>" class="blog-card">
        <div class="blog-card__poster">
            <img src="<?php echo $card['poster'] ?>" alt="<?php echo $card['title']; ?>">
        </div>
        <div class="blog-card__text">
            <div class="blog-card__top">
                <p class="blog-card__category">
                    <?php echo $card['categoryName']; ?>
                </p>
                <p class="blog-card__title">
                    <?php echo $card['title']; ?>
                </p>
                <p class="blog-card__date">
                    <?php echo $card['date']; ?>    
                </p>
            </div>
            <p class="blog-card__descr">
                <?php echo $card['shortDescr'] ?>        
            </p>
            <div class="blog-card__footer">
                <div class="row">
                    <div class="col-6">
                        <p><?php echo $card['time_to_read'] ?></p>
                    </div>
                    <div class="col-6 d-flex justify-content-end">
                        <p><?php echo $card['blog_mark'] ?> </p>
                        <svg class="icon" width="24" height="24"><use href="#icon-star-fill"></use></svg>
                    </div>
                </div>
            </div>
        </div>
    </a>
    
    <?php endif; ?>
</div>