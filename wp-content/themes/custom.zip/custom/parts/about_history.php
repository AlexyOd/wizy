<?php
    $ab_history_title = get_field('ab_history_title');
    $ab_history_subtitle = get_field('ab_history_subtitle');
    
    $ab_history_items= get_field('ab_history_items');
?>
<section class="about-history">
    <div class="about-history__main">
        <div class="container">
            <div class="row ">
                <div class="col-12 col-md-6">
                    <p class="section__title">
                        <?php
                            echo $ab_history_title
                        ?>
                    </p>
                </div>
                <div class="col-12 col-md-6">
                    <p class="section__descr">
                        <?php
                            echo $ab_history_subtitle
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="about-history__container">
        <?php
            foreach ($ab_history_items as $index => $ab_history_item) {
            
        ?>
            <div class="about-history__block">
                <div class="container">
                    <?php
                        $title = $ab_history_item['title'];
                        $subtitle = $ab_history_item['subtitle'];
                        $poster = $ab_history_item['poster'];
                        $items = $ab_history_item['items'];

                        $img_text = $ab_history_item['img_text'];
                        $img_title = $img_text['text'];
                        $img_subtitle = $img_text['ad_text'];
                        $img_type = $img_text['type'];

                        $class = 'order-1';
                        if ($index % 2 === 0) {
                            $class = '';
                        }
                    ?>
                    <div class="row">
                        <div class="col-12 col-lg-5">
                            <p class="about-history__title">
                                <?php
                                    echo $title
                                ?>
                            </p>
                            <p class="about-history__subtitle">
                                <?php
                                    echo $subtitle
                                ?>
                            </p>
                        </div>
                    </div>

                    <div class="row about-history__content">
                        <?php
                            $colClass = 'col-lg-6';
                            $colClass2 = 'col-lg-6'; 
                            $containtag = 'about-history__text';
                            foreach ($items as $item) { 
                                if ( $item['acf_fc_layout'] == 'icons')
                                {
                                    $colClass = 'col-lg-7';
                                    $colClass2 = 'col-lg-5'; 
                                } else if ( $item['acf_fc_layout'] == 'squers') {
                                    $containtag = 'about-history__squers';
                                } else if ( $item['acf_fc_layout'] == 'images') {
                                    $containtag = 'about-history__images';
                                }
                             }
                        ?>
                        <div class="col-12 <?php echo $colClass?> d-flex align-items-center <?php echo $class?>">
                            <div class="about-history__img">
                                <img src="<?php echo $poster ?>" alt="<?php echo $title ?>">
                                <?php
                                    if ($img_type != 'none') {

                                ?>

                                    <div class="about-history__img-label">
                                        <p class="<?php echo $img_type ?>">
                                            <?php
                                                echo $img_title
                                            ?>
                                        </p>
                                        <?php
                                            if($img_type != 'main'){
                                        ?>
                                            <p class="subtitle">
                                                <?php
                                                    echo $img_subtitle
                                                ?>    
                                            </p>
                                        <?php
                                            }
                                        ?>
                                    </div>
                                <?php
                                    }
                                ?>
                            </div>
                        </div> 

                        <div class="col-12 <?php echo  $colClass2?> d-flex align-items-center">
                            <div class="<?php echo $containtag ?>">
                                <?php
                                    foreach ($items as $item) {
                                        $itemType = $item['acf_fc_layout'];
                                ?>
                                    <?php
                                        if ($itemType == 'icons') {
                                            $title = $item['title'];
                                            $descr = $item['descr'];
                                            $svg = $item['svg'];
                                    ?>
                                        <div class="about-history__item-svg">
                                            <div class="about-history__item-svg__icon">
                                                <?php
                                                    echo $svg
                                                ?>
                                            </div>
                                            <div class="about-history__item-svg__title">
                                                <?php
                                                    echo $title
                                                ?>
                                            </div>
                                            <div class="about-history__item-svg__descr">
                                                <?php
                                                    echo $descr
                                                ?>
                                            </div>
                                        </div>
                                    <?php
                                        } else if ($itemType == 'squers') {
                                            $title = $item['title'];
                                            $number = $item['number'];
                                    ?>
                                        <div class="about-history__item-squers">
                                            <div class="about-history__item-squers__title">
                                                <?php
                                                    echo $title
                                                ?>
                                            </div>
                                            <div class="about-history__item-squers__number">  
                                                <?php
                                                    echo $number
                                                ?>
                                            </div>
                                        </div>
                                    <?php
                                        } else if ($itemType == 'images') {
                                            $image = $item['image'];
                                            $title = $item['title'];
                                    ?>
                                        <div class="about-history__item-image">
                                            <img src="<?php echo $image ?>" alt="<?php echo $title ?>">
                                            <div class="about-history__item-image__title">
                                                <?php
                                                    echo $title
                                                ?>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    ?>
                                <?php
                                    }
                                ?>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        <?php
            }
        ?>
    </div>

</section>