<?php
function custom_breadcrumbs($parents, $customLastPage) {
    $mainNmae = pll__('mainpagename');
    echo '<div class="breadcrumbs-list">';
    if (!is_home()) {
        echo '<a href="' . home_url() . '">'.$mainNmae.'</a>';
        if (isset($parents) && is_array($parents) && !empty($parents)){
            foreach ($parents as $parent){
                echo ' <span class="breadcrumbs-sep"> / </span> <a href="' . $parent['link'] . '">' . $parent['name'] . '</a>';
            }
        }
        if (is_category() || is_single()) {
            //echo '<span class="breadcrumbs-sep"> / </span>';
            //the_category(' <span class="breadcrumbs-sep">/</span> ');
            if (is_single()) {
                echo ' <span class="breadcrumbs-sep">/</span> ';
                the_title();
            }
        } elseif (is_page()) {
            echo ' <span class="breadcrumbs-sep">/</span> ';
            echo the_title();
        } elseif (!empty($customLastPage)) {
            echo ' <span class="breadcrumbs-sep">/</span> ';
            echo $customLastPage;
        }
    }
    echo '</div>';
}
?>
<div class="breadcrumbs">
    <div class="container">
        <?php custom_breadcrumbs(isset($parents) ? $parents : null, isset( $customLastPage) ?  $customLastPage : null); ?>
    </div>
</div>