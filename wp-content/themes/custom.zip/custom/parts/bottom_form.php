 <section class="bform">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-5 d-flex align-items-center">
                <div class="bform__cont">
                    <div class="section__title">
                        <?php
                            echo $bottomForm['title'];
                        ?>
                    </div>
                    <div class="bform__subtitle">
                        <?php
                            echo $bottomForm['subtitle'];
                        ?>
                    </div>
                    <div class="bform__text">
                        <?php
                            echo $bottomForm['text'];
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-12 offset-lg-1 col-lg-6 d-flex align-items-center">
                <?php
                    $simpleForm = get_template_directory() . '/parts/simpleForm.php';
                    if (file_exists($simpleForm)) {
                        $bform = $bottomForm['$form'];
                        include $simpleForm;
                    } else {
                        echo 'Файл simpleForm.php не найден';
                    }
                ?>
            </div>
        </div>
    </div>
</section>