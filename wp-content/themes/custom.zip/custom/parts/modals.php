<div id="modal-form-success" class="modal js-modal">
    <div class="modal__wind">
        <div class="modal__close">
            <button class="js_modal-close">
                <svg class="icon">
                    <use href="#icon-close"></use>
                </svg>
            </button>
        </div>
        <div class="modal__top">
            <p class="modal__title">
                <?php echo pll__('success_modal_title');?>
            </p>
        </div>
        <div class="modal__cont">
            <div class="modal__content">
                <?php
                    echo pll__('success_modal_message')
                ?>
                <br>
                <br>
                <br>
                <br>
                <p class="modal__p-text"><?php echo pll__('success_modal_subscribe');?></p>
                
            </div>
        </div>
    </div>
</div>

<div id="modal-form-error" class="modal js-modal">
    <div class="modal__wind">
        <div class="modal__close">
            <button class="js_modal-close">
                <svg class="icon">
                    <use href="#icon-close"></use>
                </svg>
            </button>
        </div>
        <div class="modal__top">
            <p class="modal__title">
                <?php echo pll__('error_modal_title');?>
            </p>
        </div>
        <div class="modal__cont">
            <div class="modal__content">
                <?php
                    echo pll__('error_modal_message')
                ?>
                <br>
                <br>
                <br>
                <br>
                <p class="modal__p-text"><?php echo pll__('success_modal_subscribe');?></p>
                
            </div>
        </div>
    </div>
</div>