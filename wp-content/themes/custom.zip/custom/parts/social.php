<?php
    $home_page_id = get_option('page_on_front');
    $social = get_field('social', $home_page_id);
?>
<div class="social">
    <div class="social__wind ">
        <button class="social__button">
            <svg class="icon">
                <use href="#icon-socials"></use>
            </svg>
        </button>
        <ul class="social__list">
            <?php 
                foreach ($social as $item) {
                    $social_svg_icon = $item['social_svg_icon'];
                    $type = $item['type'];
                    $social_link = $item['social_link'];
            ?>
            <li>
                <?php
                    if ($type == 'phone') {

                ?>
                    <a class="social__item" href="tel:<?php echo $social_link; ?>" target="_blank"> <?php echo $social_svg_icon; ?> </a>
                <?php
                    }
                ?>
                <?php
                    if ($type == 'email') {

                ?>
                    <a class="social__item" href="mailto:<?php echo $social_link; ?>" target="_blank"> <?php echo $social_svg_icon; ?> </a>
                <?php
                    }
                ?>
                <?php
                    if ($type == 'link') {

                ?>
                    <a class="social__item" href="<?php echo $social_link; ?>" target="_blank"> <?php echo $social_svg_icon; ?> </a>
                <?php
                    }
                ?>
            </li>
            <?php
                }
            ?>
            <li>
                <button class="social__close">
                    <svg class="icon"><use href="#icon-close"></use></svg>
                </button>
            </li>
        </ul>
    </div>
</div>