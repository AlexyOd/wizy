<div class="faq">
    <div class="faq__top">
        <p class="faq__title">
            <?php
                echo $faq['title']
            ?>
        </p>
        <div class="faq__icon">
            <svg>
                <use href="#icon-angle-right"></use>
            </svg>
        </div>
    </div>
    <div class="faq__cont">
        <p class="faq__descr">
            <?php
                echo $faq['descr']
            ?>
        </p>
    </div>
</div>