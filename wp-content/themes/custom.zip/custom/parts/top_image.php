
<div class="top_image">
    <img src="<?= $main_bg ?>" alt="<?php echo  get_the_title()?>">
</div>