<?php
    $projects_title = get_field('projects_title');
    $projects_descr = get_field('projects_descr');
    $tabs = get_field('tabs');
    $projects = get_field('projects');
    $projects_link = get_field('projects_link');
?>
<section class="projects">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6">
                <p class="section__title">
                    <?php
                        echo $projects_title 
                    ?>
                </p>
                <p class="section__descr">
                    <?php
                        echo $projects_descr
                    ?>
                </p>
            </div>
            <div class="col-12 col-md-6">
                <div id="projects-taps" class="tabs" data-tab-target="#projects">
                    <?php
                    $firstTab = true;
                    foreach ($tabs as $index => $tab) {
                        $tab_name = $tab['name'];
                        $tab_key = $tab['tab_key'];
                        $class = $firstTab ? 'tabs-item-active' : ''; // Добавляем класс "active" к первому элементу
                        $firstTab = false; // Сбрасываем флаг после первого элемента
                    ?>
                        <div class="tabs-item <?php echo $class; ?>" data-tab-key="<?php echo $tab_key; ?>">
                            <?php echo $tab_name; ?>
                        </div>
                    <?php } ?>

               </div>
            </div>
        </div>
        
        <div id="projects" class="projects-tiles">
            <div class="row">
                <?php
                    foreach ($projects as $project) {
                        $project_image = $project['image']['url'];
                        $project_name = $project['name'];
                        $project_address = $project['address'];
                        $project_key = $project['key'];
                        $project_link = $project['link']['url'];
                ?>
                    <div class="col-12 col-sm-6 col-md-4 projects-tiles__item hide" data-tab-key="<?php echo $project_key; ?>">
                        <a class="projects__item" href="<?php echo $project_link ?>" target="_blank">
                            <div class="projects__item-image">
                                <img src="<?php echo $project_image; ?>" alt="">
                            </div>
                            <div class="projects__item-footer">
                                <div class="projects__item-footer">
                                    <div class="projects__item-footer-laberl">
                                        <p class="projects__item-name">
                                            <?php
                                                echo $project_name
                                            ?>
                                        </p>
                                        <p class="projects__item-address ">
                                            <?php
                                                echo $project_address
                                            ?>
                                        </p>
                                    </div>
                                    <div class="projects__item-cercle">
                                        <svg class="icon">
                                            <use href="#icon-link"></use>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>

        <div class="row section__row" >
            <div class="col-12 d-flex">
                <a class="button button_size_xlarge button_color_black button_type_icon" href="<?php echo $direct_link ?>">
                    <?php echo pll__('read more');?>
                    <svg><use href="#icon-arrow-right"></use></svg>
                </a>
            </div>                
        </div>
        
    </div>
</section>