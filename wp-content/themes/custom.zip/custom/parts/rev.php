<?php
    $rev__title = get_field('rev__title');
    $revs = get_field('revs');
?>

<section class="rev">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <p class="section__title">
                    <?php
                        echo $rev__title
                    ?>
                </p>
            </div>
        </div>
        
        <div class="row section__row">
            
                
                <div class="col-12 col-lg-7 rev-tile__left d-flex">
                    <div class="rev__slider-container">
                        <div class="rev__slider swiper">
                            <div class="swiper-wrapper">
                                <?php
                                    foreach ($revs as $rev) {
                                        $photo = $rev['photo'];
                                        $name = $rev['name'];
                                        $company_name = $rev['company_name'];
                                        $text = $rev['text'];
                                        $date = $rev['date'];
                                ?>
                                <div class="swiper-slide">
                                    <div class="rev__item">
                                        <div class="rev__item-top">
                                            <?php echo $company_name ?>
                                        </div>
                                        <div class="rev__item-user">
                                            <img class="rev__item-photo" src="<?php echo $photo ?>" alt="<?php echo $name ?>">
                                            <div class="rev__item-user-info">
                                                <p class="rev__item-name"><?php echo $name ?></p>
                                                <p class="rev__item-date"><?php echo $date ?></p>
                                            </div>
                                        </div>
                                        <div class="rev__item-desr">
                                            <?php echo $text ?>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>

                            </div>
                            <div class="rev__slider-buttons">
                                <button class="button_color_black rev__slider-btn rev__slider--prev">
                                    <svg class="icon">
                                        <use href="#icon-angle-left"></use>
                                    </svg>
                                </button>
                                <button class="button_color_black rev__slider-btn rev__slider--next">
                                    <svg class="icon">
                                        <use href="#icon-angle-right"></use>
                                    </svg>
                                </button>
                            </div>
                        </div>    
                    </div>
                    
                </div>
                <div class="col-12 col-lg-7 rev-tile__right d-flex">
                    
                        <div class="rev__slider-nav swiper" >
                            <div class="swiper-wrapper">
                            <?php
                                foreach ($revs as $rev) {
                                    $poster = $rev['poster'];
                            ?>
                                <div class="swiper-slide">
                                    <div class="rev__poster">
                                        <img src="<?php echo $poster ?>" alt="<?php echo $company_name ?>">
                                    </div>
                                </div>
                            <?php } ?>
                            </div>
                        </div>
                    
                </div>
                
        </div>
    </div>    
</section>


