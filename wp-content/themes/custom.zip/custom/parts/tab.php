

<a href="<?php echo $tag['link'] ?>" class="tab__item <?php echo  $tag['active'];?>">
    <?php
        echo $tag['name']
    ?>
</a>