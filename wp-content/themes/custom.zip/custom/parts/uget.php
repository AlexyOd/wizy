<?php
    $uget_title = get_field('uget_title');
    $uget_descr = get_field('uget_descr');
    $uget_tile = get_field('uget_tile');
?>

<section class="uget ">
    <div class="container">
        <div class="row ">
            <div class="col-12 col-md-6">
                <p class="section__title">
                    <?php
                        echo $uget_title
                    ?>
                </p>
            </div>
            <div class="col-12 col-md-6">
                <p class="section__descr">
                    <?php
                        echo $uget_descr
                    ?>
                </p>
            </div>
        </div>
        <div class="row section__row">
            <?php
                foreach ($uget_tile as $uget) {
                    $svg = $uget['svg'];
                    $title = $uget['title'];
                    $descr = $uget['descr'];
            ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="uget__item">
                    <div class="uget__svg">
                        <?php
                            echo $svg
                        ?>
                    </div>
                    <div class="uget__title">
                        <?php
                            echo $title
                        ?>
                    </div>
                    <div class="uget__descr">
                        <?php
                            echo $descr
                        ?>
                    </div>
                </div>
            </div>
            <?php
                }
            ?>
        </div>
    </div>
</section>