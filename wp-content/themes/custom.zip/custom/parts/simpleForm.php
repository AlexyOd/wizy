 

<form class="simpleForm">
    <input type="hidden" name="project_name" value="<?php echo $btitle ?>">
    <input type="hidden" name="admin_email" value="<?php echo get_option('admin_email'); ?>">
    <input type="hidden" name="form_subject" value="<?php echo pll__('form title');?>">
    <?php
        foreach ( $bform as $field ) {
            $type = $field['acf_fc_layout'];
    ?>
        <?php
            if ($type == 'input') {
                $name = $field['name'];
                $placeholder = $field['placeholder'];
        ?>
            <div class="simpleForm__row">
                <div class="custom-input">
                    <input type="text" placeholder="<?php echo $placeholder ?>" name="<?php echo $name ?>">
                </div>
            </div>
        <?php
            }
        ?>

        <?php
            if ($type == 'dropdown') {
                $list = $field['options'];
        ?>
            <div class="simpleForm__row">
                <div class="custom-dropdown">
                    <div class="custom-select custom-dropdown__btn">
                        <div class="custom-select__input">
                            <div class="custom-input">
                                <input type="text" disabled placeholder="<?php
                                    echo $field['placeholder']
                                ?>" name="city">
                            </div>
                            <button class="custom-select__button">
                                <svg class="icon" width="14">
                                    <use href="#arrow-down"></use>
                                </svg>
                            </button>
                        </div>
                        <ul class="custom-dropdown__list">
                            <?php
                                foreach ( $list as $item ) {
                                    $option = $item['option'];   
                            ?>
                                <li>
                                    <p class="custom-select__item">
                                        <?php
                                            echo $option 
                                        ?>
                                    </p>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div> 
            </div> 
        <?php
            }
        ?>

        <?php
            if ($type == 'area') {
                $placeholder = $field['placeholder'];
                $name = $field['name'];
        ?>
            <div class="simpleForm__row">
                <div class="custom-input">
                    <textarea name="<?php echo $name ?>" placeholder="<?php echo $placeholder ?>"></textarea>
                </div>
            </div>
        <?php
            }
        ?>

    <?php
        }
    ?>
    <div class="simpleForm__footer">
        <button class="button button_size_xlarge button_color_black" type="submit">
            <?php
                echo pll__('submit')
            ?>
        </button>
    </div>
</form>