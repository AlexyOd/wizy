<?php
    // Получаем ID главной страницы
    $home_page_id = get_option('page_on_front');

    // Получаем значение поля ACF с именем "custom_field" из главной страницы
    $hederTitle = get_field('header_title', $home_page_id);
    $ranges = get_field('range', $home_page_id);
    
    $title_type = get_field('title_type', $home_page_id);
    $checkbox_types = get_field('checkbox_types', $home_page_id);

    $needs__title = get_field('needs_title', $home_page_id);
    $checkbox_needs = get_field('checkbox_needs', $home_page_id);

    $location_title = get_field('location_title', $home_page_id);
    $locations = get_field('locations', $home_page_id);

    $fudament_title = get_field('fudament_title', $home_page_id);
    $checkbox_fundament = get_field('checkbox_fundament', $home_page_id);

    
    $fields = get_field('fields', $home_page_id);

    $success = get_field('calculateFormSuccess', $home_page_id);
    $error = get_field('calculateFormError', $home_page_id);
    
?>

<div id="popup-calculate" class="modal js-modal">
    <div class="modal__wind">
        <div class="modal__close">
            <button class="js_modal-close">
                <svg class="icon">
                    <use href="#icon-close"></use>
                </svg>
            </button>
        </div>
        <div class="modal__top">
            <p class="modal__title"><?php echo $hederTitle ?></p>
        </div>
        <form id="modal-form" class="modal__cont js-calculate-form">
            <input type="hidden" name="project_name" value="<?php echo $hederTitle ?>">
            <input type="hidden" name="admin_email" value="<?php echo get_option('admin_email'); ?>">
            <input type="hidden" name="form_subject" value="<?php echo pll__('form title');?>">
            <div class="modal__content">
                <?php 
                    $firstTab = true;
                    foreach ( $ranges as $range ) { 
                    $range_title = $range['range_title'];
                    $min = $range['min'];
                    $max = $range['max'];
                    $unit = $range['unit'];
                    $value = $range['value'];
                    $class = $firstTab ? 'first' : '';
                    $firstTab = false;
                ?>
                <div class="row">
                    <div class="col-12">
                        <p class="modal__p-title <?php echo $class ?>">
                            <?php
                                echo $range_title;
                            ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="range-slider">
                            <input type="hidden" name="<?php echo $range_title; ?>" >
                            <div class="slider" data-min="<?php echo $min ?>" data-value="<?php echo $value ?>" data-max="<?php echo $max ?>" data-unit="<?php echo $unit ?>"></div>
                            <div class="range-slider__footer">
                                <div class="range-slider__min"></div>
                                <div class="range-slider__max"></div>
                            </div>
                        </div>
                    </div>
                </div> 
                <?php } ?>

                <div class="row">
                    <div class="col-12">
                        <p class="modal__p-title">
                            <?php
                                echo $title_type
                            ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <?php 
                    $first_radio = true;
                    foreach ( $checkbox_types as $checkbox_type ) {
                        $label = $checkbox_type['checkbox_label'];
                    ?>                    
                    <div class="col-12">
                        <label class="costom-radio">
                            <input type="radio" name="<?php echo $title_type ?>" value="<?php echo $label ?>" <?php echo $first_radio ? 'checked' : ''; ?>>
                            <span></span>
                            <?php echo $label ?>
                        </label>
                    </div>
                    <?php 
                        $first_radio = false;
                    } ?>
                </div>

                <div class="row">
                    <div class="col-12">
                        <p class="modal__p-title">
                            <?php
                                echo $needs__title
                            ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <?php 
                    $first_radio = true;
                    foreach ( $checkbox_needs as $checkbox_need ) {
                        $label = $checkbox_need['checkbox_label'];
                    ?>                    
                    <div class="col-12 col-md-6">
                        <label class="costom-radio">
                            <input type="radio" name="<?php echo $needs__title ?>" value="<?php echo $label ?>" <?php echo $first_radio ? 'checked' : ''; ?>>
                            <span></span>
                            <?php echo $label ?>
                        </label>
                    </div>
                    <?php 
                        $first_radio = false;
                    } ?>
                </div>


                <div class="row">
                    <div class="col-12">        
                        <p class="modal__p-title">
                            <?php
                                echo $location_title
                            ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="custom-dropdown">
                            <div class="custom-select custom-dropdown__btn">
                                <div class="custom-select__input">
                                    <div class="custom-input">
                                        <input type="text" disabled placeholder="" name="city">
                                    </div>
                                    <button class="custom-select__button">
                                        <svg class="icon" width="14">
                                            <use href="#arrow-down"></use>
                                        </svg>
                                    </button>
                                </div>
                                <ul class="custom-dropdown__list">
                                    <?php
                                        foreach ( $locations as $location ) {
                                            $location = $location['location'];
                                    ?>
                                    
                                        <li>
                                            <p class="custom-select__item">
                                                <?php
                                                    echo $location 
                                                ?>
                                            </p>
                                        </li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-12">
                        <p class="modal__p-title">
                            <?php
                                echo $fudament_title
                            ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <?php 
                    $first_radio = true;
                    foreach ( $checkbox_fundament as $fundament ) {
                        $label = $fundament['option'];
                    ?>                    
                    <div class="col-12 col-md-6">
                        <label class="costom-radio">
                            <input type="radio" name="<?php echo $fudament_title ?>" value="<?php echo $label ?>" <?php echo $first_radio ? 'checked' : ''; ?>>
                            <span></span>
                            <?php echo $label ?>
                        </label>
                    </div>
                    <?php 
                        $first_radio = false;
                    } ?>
                </div>
                <?php 
                
                foreach ( $fields as $field ) {
                    $field_title = $field['title'];
                    $field_name = $field['name'];
                    $field_placeholder = $field['placeholder'];
                ?>                    
                    
                <div class="row">
                    <div class="col-12">        
                        <p class="modal__p-title">
                            <?php echo $field_title ?>
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">        
                        <div class="custom-input">
                            <input type="text" placeholder="<?php echo $field_placeholder ?>" name="<?php echo $field_name ?>">
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </form>
        <div class="modal__cont js-calculate-form-success js-hidden">
            <div class="modal__content">
                <?php
                    echo $success
                ?>
            </div>
        </div>

        <div class="modal__cont js-calculate-form-error js-hidden">
            <div class="modal__content">
                <?php
                    echo $error
                ?>
            </div>
        </div>
        <div class="modal__footer">
            <button class="button button_size_xlarge button_color_black button_type_fwidth js-calculate-form_submit justify-content-center" type="submit" data-formId="modal-form">
                <?php
                    echo pll__('submit')
                ?>
            </button>
        </div>
    </div>
</div>