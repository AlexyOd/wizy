<?php
    $direct_title =  get_field('direct_title');
    $direct_descr =  get_field('direct_descr');
    $direct_rep =  get_field('direct_rep');
    $direct_link =  get_field('direct_link');
?>
<section class="directions">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6">
                <p class="section__title">
                    <?php
                        echo $direct_title
                    ?>
                </p>
            </div>
            <div class="col-12 col-md-6">
                <p class="section__descr">
                    <?php
                        echo $direct_descr
                    ?>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="directions-tile">
                    <?php 
                        foreach ($direct_rep as $direct) {
                            $name = $direct['name'];
                            $descr = $direct['descr'];
                        ?>
                            <div class="directions-tile__item">
                                <div class="directions__name">
                                    <?php
                                        echo $name
                                    ?>
                                </div>
                                <div class="directions__descr">
                                    <?php
                                        echo $descr
                                    ?>
                                </div>
                            </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="directions__footer">
                    <a class="button button_size_xlarge button_color_black button_type_icon" href="<?php echo $direct_link ?>">
                        <?php echo pll__('read more');?>
                        <svg><use href="#icon-arrow-right"></use></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>