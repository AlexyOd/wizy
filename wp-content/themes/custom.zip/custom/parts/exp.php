<?php
    $exps = get_field('exp');
?>
<section class="exp">
    <div class="container">
        <div class="exp__container">
            <?php
                foreach ($exps as $exp) {
                    $exp_number = $exp['number'];
                    $exp_text = $exp['text'];
            ?>
                <div class="exp__item">
                    <div class="exp__cont">
                        <div class="exp__number">
                            <?php
                                echo $exp_number;
                            ?>
                        </div>
                        <div class="exp__text">
                            <?php
                                echo $exp_text;
                            ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</section>