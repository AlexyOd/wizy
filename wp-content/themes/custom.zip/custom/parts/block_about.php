
<?php
    $bAbout__title = get_field('bAbout__title');
    $bAbout_yFrame = get_field('bAbout_yFrame');
    $bAbout_title_small = get_field('bAbout_title_small');
    $bAbout_title_big = get_field('bAbout_title_big');
    $bAbout_descr = get_field('bAbout_descr');
    $bAbout_link = get_field('bAbout_link');
?>


<section class="bAbout">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <p class="section__title">
                    <?php
                        echo $bAbout__title
                    ?>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-7">
                <div class="bAbout__video">
                    <?php
                        echo $bAbout_yFrame
                    ?>
                </div>
            </div>
            <div class="col-12 col-lg-5">
                <p class="bAbout__title-small">
                    <?php
                        echo $bAbout_title_small
                    ?>
                </p>
                <p class="bAbout__title-big">
                    <?php   
                        echo $bAbout_title_big
                    ?>
                </p>
                <p class="bAbout__descr">
                    <?php
                        echo $bAbout_descr
                    ?>
                </p>
                <div class="bAbout__footer">
                    <a class="button button_size_xlarge button_color_black button_type_icon" href="<?php echo $bAbout_link ?>">
                        <?php echo pll__('read more');?>
                        <svg><use href="#icon-arrow-right"></use></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>