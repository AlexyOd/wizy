<?php
     $main_bg = get_field('main_image');
     $main_title = get_field('main_title');
     $main_subtitle = get_field('main_subtitle');
     $current_language = pll_current_language();
                    
?>

<div class="main-top">
    <div class="main-top__img">
        <img src="<?php echo $main_bg?>" alt="main_bg">
        
    </div>
    <div class="main-top__cont">
        <div class="container">
            <div class="main-top__title">
                <?php
                    echo $main_title;
                ?>
            </div>
            <div class="main-top__subtitle">
                <?php
                    echo $main_subtitle;
                ?>
            </div>
            <div class="main-top__btns">
                
                <button class="button button_size_xlarge button_color_black js_modal-open" data-modal-id="popup-calculate"><?php echo pll__('header_button');?>  </button>
                
                <button id="srllToForm" class="button button_size_xlarge button_color_white-blur button_type_icon">
                
                    <?php echo pll__('get consilation');?>
                    <svg><use href="#icon-arrow-right"></use></svg>
                </button>
            </div>
        </div>
    </div>
</div>