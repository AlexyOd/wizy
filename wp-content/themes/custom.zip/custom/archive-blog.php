<div class="wrapper">
    <?php
    $posts_per_page = $wp_query->query_vars['posts_per_page'];
    $email = get_theme_mod('email');
    $phone = get_theme_mod('phone');
    get_header(); ?>
    <main class="main portfolio">
        <?php
            $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
            if (file_exists($breadcrumbs)) {
                $customLastPage = pll__('blog_page');
                include $breadcrumbs;
            } else {
                echo 'Файл breadcrumbs.php не найден';
            }
        ?>

        <div class="portfolio__top">
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-md-6">
                        <p class="section__title">
                            <?php
                               echo pll__('blog_title')
                            ?>
                        </p>
                        <p class="section__descr">
                            <?php
                               echo pll__('blog_subtitle')
                            ?>
                        </p>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="tab__list">
                            <?php
                                // таб "все" 
                                $current_date_query = (isset($_GET['date_query'])) ? $_GET['date_query'] : '';
                                $tab_lastWeek = '';
                                $tab_lastmonth = '';
                                if($current_date_query) {
                                    if($current_date_query[0]['after'] == '1 week ago'){
                                        $tab_lastWeek = 'active';
                                    } elseif($current_date_query[0]['after'] == '1 month ago'){
                                        $tab_lastmonth = 'active';
                                    }
                                }
                                $tag = array(
                                    'link' => esc_url(remove_query_arg('date_query')),
                                    'active' => $current_date_query ? '' : 'active',
                                    'name' => pll__('tab_all')
                                );

                                $tab_part = get_template_directory() . '/parts/tab.php';
                                if (file_exists($tab_part)) {
                                    include $tab_part;
                                } else {
                                    echo 'Файл tab.php не найден';
                                }
                                // fin таб "все"
                                // таб за последние 7 дней
                                $lastWeek = array(
                                    'post_type'      => 'blog', // Тип записи (может быть 'post', 'page' и т. д.)
                                    'post_status'    => 'publish', // Статус публикации
                                    'date_query'     => array(
                                        array(
                                            'after' => '1 week ago', // Записи, опубликованные после этой даты
                                        ),
                                    ),
                                );
                                
                                
                                // Получение ссылки с параметрами запроса
                                $link_to_last_week_posts = add_query_arg( $lastWeek, home_url('/blog/') );

                                $tag = array(
                                    'link' => esc_url( $link_to_last_week_posts ),
                                    'active' => $tab_lastWeek,
                                    'name' => pll__('last_week')
                                );

                                $tab_part = get_template_directory() . '/parts/tab.php';
                                if (file_exists($tab_part)) {
                                    include $tab_part;
                                } else {
                                    echo 'Файл tab.php не найден';
                                }

                                // fin таб за последние 7 дней

                                // таб за месяц
                                $lastWeek = array(
                                    'post_type'      => 'blog', // Тип записи (может быть 'post', 'page' и т. д.)
                                    'post_status'    => 'publish', // Статус публикации
                                    'date_query'     => array(
                                        array(
                                            'after' => '1 month ago', // Отсчитываем месяц назад от текущей даты
                                        ),
                                    ),
                                );
                                
                                // Получение ссылки с параметрами запроса
                                $link_to_last_week_posts = add_query_arg( $lastWeek, home_url('/blog/') );

                                $tag = array(
                                    'link' => esc_url( $link_to_last_week_posts ),
                                    'active' => $tab_lastmonth,
                                    'name' => pll__('last_month')
                                );

                                $tab_part = get_template_directory() . '/parts/tab.php';
                                if (file_exists($tab_part)) {
                                    include $tab_part;
                                } else {
                                    echo 'Файл tab.php не найден';
                                }

                                // fin таб за месяц
                            ?>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <section style="padding-bottom: 0">
            <div class="container">
                <div class="row">
                    <?php
                        $categories = get_categories();
                        $current_date_query = (isset($_GET['date_query'])) ? $_GET['date_query'] : '';
                        $args = array(
                            'post_type'      => 'blog',  // Замените на ваш тип записей
                            'post_status'    => 'publish',
                            'posts_per_page' => $posts_per_page,
                            'paged'          => $paged
                        );
                        if ($current_date_query) {
                            $date_query_args = array(
                                'after' => $current_date_query,
                            );
                        
                            $args['date_query'] = array($date_query_args);
                        }
                        $new_query = new WP_Query($args);
                        
                        if ( $new_query->have_posts() ) :
                            $first_post = true;
                            while ($new_query->have_posts()) : $new_query->the_post();
                    ?>
                        <div class="col-12 col-lg-6">
                            <?php
                                $categories = get_the_category();
                                $blog_card = get_template_directory() . '/parts/blog_card.php';
                                if (file_exists($blog_card)) {
                                    $card = array(
                                        'title' => get_the_title(),
                                        'categoryName' => $categories[0]->cat_name,
                                        'date' =>  get_the_date('d F, Y'),
                                        'shortDescr' => get_field('korotkoe_opisanie'),
                                        'blog_mark' =>get_field('blog_mark'),
                                        'poster' => get_field('poster'),
                                        'time_to_read' =>  get_field('time_to_read'),
                                        'link' =>  get_permalink()
                                    );
                                    include $blog_card;
                                } else {
                                    echo 'Файл blog_card.php не найден';
                                }
                            ?>
                        </div>
                    <?php
                        $first_post = false;
                        endwhile;
                    ?>
                </div>
                
            </div>
        </section>
        <section>
            <div class="container">
                <?php 
                    kama_pagenavi($before = '', $after = '', $echo = true, $args = array(), $wp_query = $new_query);
                ?>
                <?php 
                    wp_reset_postdata();
                    endif; 
                ?>
            </div>
        </section>
        <section class="portfolio-bform">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-5 d-flex align-items-center">
                        <div class="bform__cont">
                            <div class="section__title">
                                <?php
                                    echo pll__('form_title')
                                ?>
                            </div>
                           
                            <p class="portfolio-bform__text"> <?php echo $email ?> <p>
                            <p class="portfolio-bform__text"> <?php echo $phone ?> <p>
                        </div>
                    </div>
                    <div class="col-12 offset-lg-1 col-lg-6 d-flex align-items-center">
                        <div style="width: 100%">
                            <p class="portfolio-bform__simp-p">
                                <?php
                                    echo pll__('form_descr')
                                ?>
                            </p>
                            <?php
                                $simpleForm = get_template_directory() . '/parts/simpleForm.php';
                                if (file_exists($simpleForm)) {
                                    $bform = array(
                                        array(
                                            'acf_fc_layout' => 'input',
                                            'name' => 'email',
                                            'placeholder' => pll__('form_emael_placeholder')
                                        ),
                                    );
                                    include $simpleForm;
                                } else {
                                    echo 'Файл simpleForm.php не найден';
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php get_footer(); ?>

