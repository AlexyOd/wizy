</div>


<?php
  $linkedin = get_theme_mod('linkedin');
  $instagram = get_theme_mod('instagram');
  $facebook = get_theme_mod('facebook');
  $tiktok = get_theme_mod('tiktok');
  $email = get_theme_mod('email');
  $phone = get_theme_mod('phone');
?>

<footer class="footer svg_dynamic" data-aos="fade-up">
  <div class="container">
      <div class="row">
        <div class="col-12 col-lg-3">
          <a href="<?php echo get_home_url(); ?>/">
            <img class="footer__logo"src="<?php echo get_template_directory_uri() ?>/dist/img/icons/footer_logo.svg" alt="logo">
          </a>
          <ul class="footer-social">
            <?php if($phone):?>
              <li>
                <a href="<?php echo $phone;?>" title="<?php echo $phone;?>">
                  <svg class="icon">
                    <use href="#icon-phone"></use>
                  </svg>
                </a>
              </li>
            <?php endif; ?>
            <?php if($linkedin):?>
              <li>
                <a href="<?php echo $linkedin;?>" title="<?php echo $linkedin;?>">
                  <svg class="icon">
                    <use href="#icon-linkedin"></use>
                  </svg>
                </a>
              </li>
            <?php endif; ?>
            <?php if($instagram):?>
              <li>
                <a href="<?php echo $instagram;?>" title="<?php echo $instagram;?>">
                  <svg class="icon">
                    <use href="#icon-instagram"></use>
                  </svg>
                </a>
              </li>
            <?php endif; ?>
            <?php if($facebook):?>
              <li>
                <a href="<?php echo $facebook;?>" title="<?php echo $facebook;?>">
                  <svg class="icon">
                    <use href="#icon-facebook"></use>
                  </svg>
                </a>
              </li>
            <?php endif; ?>
            <?php if($tiktok):?>
              <li>
                <a href="<?php $tiktok;?>" title="<?php echo $tiktok;?>">
                  <svg class="icon">
                    <use href="#icon-tiktok"></use>
                  </svg>
                </a>
              </li>
            <?php endif; ?>
            <?php if($email):?>
              <li>
                <a href="<?php $email;?>" title="<?php echo $email;?>">
                  <svg class="icon">
                    <use href="#icon-email"></use>
                  </svg>
                </a>
              </li>
            <?php endif; ?>
          </ul>
          <div class="footer-contacts">
            <ul class="footer__links">
              <li>
                <p class="footer__h1">
                  <?php echo pll__('Our contacts');?>    
                </p>
              </li>
              <?php if($phone):?>
                <li>
                  <a href="tel:<?php echo $phone;?>" title="<?php echo $phone;?>">
                      <?php echo $phone?>
                  </a>
                </li>
              <?php endif; ?>
              <?php if($email):?>
                <li>
                  <a href="tel:<?php echo $email;?>" title="<?php echo $email;?>">
                      <?php echo $email?>
                  </a>
                </li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-5">
          <div class="row">
            <div class="col-12 col-lg-6">
              <p class="footer__h1">
                <?php echo pll__('fotoer site map title');?>    
              </p>
              <?php
                $args = array(
                  'container'     => '',
                  'theme_location' => 'footer',
                  'menu_id' => '',
                );
                wp_nav_menu($args);
              ?>
            </div>
            <div class="col-12 col-lg-6">
              <p class="footer__h1">
                <?php echo pll__('footer info');?>    
              </p>
              <?php
                $args = array(
                  'container'     => '',
                  'theme_location' => 'footer-info',
                  'menu_id' => '',
                );
                wp_nav_menu($args);
              ?>
            </div>
          </div>
          

          
          
        </div>
        <div class="col-12 col-md-6 col-lg-4">
          <p class="footer__h1">
            <?php echo pll__('form title');?>    
          </p>

          <form class="simpleForm">
          <input type="hidden" name="project_name" value="<?php bloginfo('name'); ?>">
          <input type="hidden" name="admin_email" value="<?php echo get_option('admin_email'); ?>">
          <input type="hidden" name="form_subject" value="<?php echo pll__('form title');?>">
            <div class="simpleForm__row">
                <div class="custom-input custom-input_color_transparent">
                    <input type="text"  placeholder="E-mail" name="email">
                </div>
            </div>
            <div class="simpleForm__footer">
              <button class="button button_size_large  button_color_white" type="submit">
                  <?php
                      echo pll__('submit')
                  ?>
              </button>
            </div>
          </form>
        </div>
      </div>
  </div>
  <button class="button button_color_black dbtn">
    <svg class="icon">
        <use href="#icon-angle-up"></use>
      </svg>    
  </buttom>
  <!-- Modal -->

</footer>
</div>
<div style="display: none">
  <?php
    // Путь к файлу svg_icons.php относительно текущей темы
    $svg_icons_php_path = get_template_directory() . '/parts/svg_icons.php';

    // Проверяем, существует ли файл
    if (file_exists($svg_icons_php_path)) {
      // Включаем содержимое svg_icons.php
      include $svg_icons_php_path;
    } else {
      // Если файл не найден, выводим сообщение об ошибке
      echo 'Файл svg_icons.php не найден';
    }
  ?>
</div>
<?php wp_footer(); ?>


<?php
  $popup = get_template_directory() . '/parts/popup.php';
  if (file_exists($popup)) {
    include $popup;
  } else {
    echo 'Файл popup.php не найден';
  }
?>

<?php
  $social = get_template_directory() . '/parts/social.php';
  if (file_exists($social)) {
    include $social;
  } else {
    echo 'Файл social.php не найден';
  }
?>

<?php
  $modals = get_template_directory() . '/parts/modals.php';
  if (file_exists($modals)) {
    include $modals;
  } else {
    echo 'Файл modals.php не найден';
  }
?>

</body>

</html>

