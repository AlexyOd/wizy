<div class="wrapper wrapper_404">
    <?php
    /*
    Template Name: 404
    */
    get_header(); ?>
    <main class="main">
        <section class="nf_404">
            <div class="container">
                <img src="<?php echo get_template_directory_uri(); ?>/dist/img/404.png" alt="404">
                <p class="nf_404__text"><?php echo pll__('404_page_text');?></p>
                <a class="button button_size_xlarge button_color_black" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo pll__('404_link_text');?></a>
            </div>
        </section>
    </main>
</div>
<?php get_footer(); ?>

