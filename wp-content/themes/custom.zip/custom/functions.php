<?php
add_theme_support( 'post-thumbnails' ); // для всех типов постов
add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

register_nav_menus();


add_action( 'template_redirect', function () {
	global $wpseo_og;

	if ( isset( $wpseo_og ) ) {
		remove_action( 'wpseo_opengraph', [ $wpseo_og, 'locale' ], 1 );
	}
}, 1000 );

//Scripts
function jqueryIntegration() {
	// wp_deregister_script( 'jquery' );
	// wp_register_script( 'jquery', get_template_directory_uri() . '/libs/jquery/jquery-v3.7.1.min.js' );
	// wp_enqueue_script( 'jquery' );
}

add_action( 'wp_print_styles', 'wps_deregister_styles', 100 );
function wps_deregister_styles() {
	wp_deregister_style( 'contact-form-7' );
}

add_action( 'wp_enqueue_scripts', 'jqueryIntegration' );

add_action( 'wp_footer', 'add_scripts' ); // приклеем ф-ю на добавление скриптов в футер
function add_scripts() {
	if ( is_admin() ) {
		return false;
	}
	// wp_enqueue_script( 'slick', get_template_directory_uri() . '/libs/slick.min.js', '', '', true );
	// wp_enqueue_script( 'fancybox', get_template_directory_uri() . '/libs/jquery.fancybox.min.js', '', '', true );
	// wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/libs/bootstrap.min.js', '', '', true );
	// wp_enqueue_script( 'move', get_template_directory_uri() . '/libs/jquery.event.move.js', '', '', true );
	// wp_enqueue_script( 'twentytwenty', get_template_directory_uri() . '/libs/jquery.twentytwenty.js', '', '', true ); 
	// wp_enqueue_script( 'lottie', get_template_directory_uri() . '/libs/lottie.min.js', '', '', true );
	// wp_enqueue_script( 'waypoints', get_template_directory_uri() . '/libs/jquery.waypoints.min.js', '', '', true );
	// wp_enqueue_script( 'counter', get_template_directory_uri() . '/libs/jquery.countup.min.js', '', '', true );
	// 	wp_enqueue_script( 'slick', get_template_directory_uri() . '/libs/slick/slick.min.js', '', '', true );
	wp_enqueue_script( 'main', get_template_directory_uri() . '/dist/js/common.js', '', '', true ); // и скрипты шаблона
}

add_action( 'wp_print_styles', 'add_styles' ); // приклеем ф-ю на добавление стилей в хедер
function add_styles() {
	if ( is_admin() ) {
		return false;
	}
	// wp_enqueue_style( 'fancybox', get_template_directory_uri() . '/libs/jquery.fancybox.min.css' );
	// wp_enqueue_style( 'slick', get_template_directory_uri() . '/libs/slick.css' );
	// wp_enqueue_style( 'twentytwenty', get_template_directory_uri() . '/libs/twentytwenty.css' );
	// wp_enqueue_style( 'fontello', get_template_directory_uri() . '/libs/fontello/css/fontello.css' );
	// wp_enqueue_style( 'slick', get_template_directory_uri() . '/libs/slick/slick.css' );
	// wp_enqueue_style( 'slick', get_template_directory_uri() . '/libs/slick/slick-theme.css' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/libs/bootstrap/bootstrap-grid.min.css' );
	wp_enqueue_style( 'noUiSlider', get_template_directory_uri() . '/libs/noUiSlider/nouislider.min.css' );
	wp_enqueue_style( 'main', get_template_directory_uri() . '/dist/css/main.css' );
}

// changing excerpt length
add_filter( 'excerpt_length', function () {
	return 20;
} );

//custom menu
function add_submenu_icon_to_menu($items, $args) {
    // Проверяем, что текущее меню - 'main'
    if ($args->theme_location == 'main') {
        foreach ($items as &$item) {
            if (in_array('menu-item-has-children', $item->classes)) {
                $item->title .= '<svg width="12" height="7" viewBox="0 0 12 7">
                    <path d="M6.36245 6.62005L11.6725 1.04705C11.7611 0.954058 11.8105 0.830516 11.8105 0.702046C11.8105 0.573575 11.7611 0.450035 11.6725 0.357047L11.6665 0.351046C11.6235 0.305811 11.5718 0.269792 11.5144 0.245178C11.4571 0.220564 11.3953 0.207871 11.333 0.207871C11.2706 0.207871 11.2088 0.220564 11.1515 0.245178C11.0942 0.269792 11.0424 0.305811 10.9995 0.351046L5.99945 5.59905L1.00145 0.351046C0.958479 0.305811 0.906753 0.269792 0.84942 0.245178C0.792087 0.220564 0.730346 0.207871 0.667953 0.207871C0.605559 0.207871 0.543818 0.220564 0.486485 0.245178C0.429152 0.269792 0.377425 0.305811 0.334453 0.351046L0.328452 0.357047C0.239807 0.450035 0.190356 0.573575 0.190356 0.702046C0.190356 0.830516 0.239807 0.954058 0.328452 1.04705L5.63845 6.62005C5.68515 6.66906 5.74131 6.70808 5.80354 6.73474C5.86576 6.7614 5.93276 6.77515 6.00045 6.77515C6.06815 6.77515 6.13514 6.7614 6.19737 6.73474C6.25959 6.70808 6.31575 6.66906 6.36245 6.62005Z"/>
                </svg>';
            }
        }
    }

    return $items;
}

add_filter('wp_nav_menu_objects', 'add_submenu_icon_to_menu', 10, 2);


//Customizer
add_action('customize_register', function ( $customizer ) {
	// contacts
	$customizer->add_section(
		'contacts',
		array(
			'title'    => 'Контактные данные',
			'priority' => 11,
		)
	);

	//linkedin
	$customizer->add_setting(
		'linkedin',
		array( 'default' => '#' )
	);
	$customizer->add_control(
		'linkedin',
		array(
			'label'   => 'Ссылка на LinkedIn',
			'section' => 'contacts',
			'type'    => 'text',
		)
	);

	//instagram
	$customizer->add_setting(
		'instagram',
		array( 'default' => '#' )
	);
	$customizer->add_control(
		'instagram',
		array(
			'label'   => 'Инстаграм',
			'section' => 'contacts',
			'type'    => 'text',
		)
	);

	//facebook
	$customizer->add_setting(
		'facebook',
		array( 'default' => '#' )
	);
	$customizer->add_control(
		'facebook',
		array(
			'label'   => 'Facebook',
			'section' => 'contacts',
			'type'    => 'text',
		)
	);

	//tiktok
	$customizer->add_setting(
		'tiktok',
		array( 'default' => '#' )
	);
	$customizer->add_control(
		'tiktok',
		array(
			'label'   => 'Тикток',
			'section' => 'contacts',
			'type'    => 'text',
		)
	);

	//email
	$customizer->add_setting(
		'email',
		array( 'default' => '#' )
	);
	$customizer->add_control(
		'email',
		array(
			'label'   => 'e-mail',
			'section' => 'contacts',
			'type'    => 'text',
		)
	);

	//phone
	$customizer->add_setting(
		'phone',
		array( 'default' => '#' )
	);
	$customizer->add_control(
		'phone',
		array(
			'label'   => 'Телефон',
			'section' => 'contacts',
			'type'    => 'text',
		)
	);

	 

	

});

add_action( 'after_setup_theme', function () {
	register_nav_menus( [
		'main'     => 'Меню в шапке',
		'footer'     => 'Меню в подвале',
		'footer-info'     => 'Информационное меню в подвале ',
	] );
} );



pll_register_string( '0', 'header_button');
pll_register_string( '1', 'fotoer site map title');
pll_register_string( '2', 'footer info');
pll_register_string( '3', 'form title');
pll_register_string( '4', 'form subtitle');
pll_register_string( '5', 'Our contacts');
pll_register_string( '6', 'submit');
pll_register_string( '7', 'read more');
pll_register_string( '8', 'get consilation');
pll_register_string( '9', 'success_modal_title');
pll_register_string( '10', 'success_modal_message');
pll_register_string( '11', 'success_modal_subscribe');
pll_register_string( '12', 'error_modal_title');
pll_register_string( '13', 'error_modal_message');
pll_register_string( '14', 'mainpagename');
pll_register_string( '15', 'contact_info_title');
pll_register_string( '16', '404_page_text');
pll_register_string( '16', '404_link_text');
pll_register_string( '17', 'pagename_services');

pll_register_string( '18', 'tab_all');
pll_register_string( '19', 'projects_title');
pll_register_string( '20', 'projects_subtitle');
pll_register_string( '21', 'projects_page');
pll_register_string( '22', 'projects_about');
pll_register_string( '23', 'status');
pll_register_string( '24', 'zadachi_title');
pll_register_string( '25', 'etapi_title');

pll_register_string( '26', 'form_title');
pll_register_string( '27', 'form_descr');
pll_register_string( '28', 'form_emael_placeholder');
pll_register_string( '29', 'faq_title');
pll_register_string( '30', 'faq_form_title');
pll_register_string( '31', 'faq_form_descr');

pll_register_string( '32', 'projects_in-work_title');
pll_register_string( '33', 'projects_in-work_subtitle');

pll_register_string( '34', 'plog_page');
pll_register_string( '34', 'back_to_blogs');
pll_register_string( '34', 'mark_this_blog');
pll_register_string( '34', 'similar_blog');

pll_register_string( '35','blog_page');
pll_register_string( '36','blog_title');
pll_register_string( '37','blog_subtitle');
pll_register_string( '38','last_week');
pll_register_string('39','last_month');




add_action( 'init', 'register_services' );
add_action( 'init', 'register_projects' );
add_action( 'init', 'register_wprojects' );
add_action( 'init', 'register_blog' );



function register_services() {
	$labels = array(
		'name'               => 'Услуги',
		'singular_name'      => 'Услуга',
		'add_new'            => 'Добавить услугу',
		'add_new_item'       => 'Добавить новую услугу',
		'edit_item'          => 'Редактировать услугу',
		'new_item'           => 'Новая услуга',
		'all_items'          => 'Все услуги',
		'view_item'          => 'Просмотр услуг на сайте',
		'search_items'       => 'Искать услуги',
		'not_found'          => 'Услуги не найдены.',
		'not_found_in_trash' => 'В корзине нет услуг.',
		'menu_name'          => 'Услуги'
	);
	$args   = array(
		'labels'      => $labels,
		'public'      => true,
		'menu_icon'   => 'dashicons-cart',
		'has_archive' => false,
		'supports'    => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		'taxonomies'  => array( 'post_tag' )
	);
	register_post_type( 'services', $args );
}
 

function register_projects() {
	$labels = array(
		'name'               => 'Проекты',
		'singular_name'      => 'Проект',
		'add_new'            => 'Добавить проект',
		'add_new_item'       => 'Добавить новый проект',
		'edit_item'          => 'Редактировать проект',
		'new_item'           => 'Новый проект',
		'all_items'          => 'Все проекты',
		'view_item'          => 'Просмотр проектов на сайте',
		'search_items'       => 'Искать Проекты',
		'not_found'          => 'Проекты не найдены.',
		'not_found_in_trash' => 'В корзине нет проектов.',
		'menu_name'          => 'Проекты'
	);
	$args   = array(
		'labels'      => $labels,
		'public'      => true,
		'menu_icon'   => 'dashicons-admin-multisite',
		'has_archive' => true,
		'supports'    => array( 'title', 'editor', 'thumbnail', 'category'  ),
		'taxonomies'  => array( 'post_tag','category' )
	);
	register_post_type( 'projects', $args );
}

function register_wprojects() {
	$labels = array(
		'name'               => 'Проекты в работе',
		'singular_name'      => 'Проект в работе',
		'add_new'            => 'Добавить проект в работе',
		'add_new_item'       => 'Добавить новый проект в работе',
		'edit_item'          => 'Редактировать проект в работе',
		'new_item'           => 'Новый проект в работе',
		'all_items'          => 'Все проекты в работе',
		'view_item'          => 'Просмотр проектов в работе на сайте',
		'search_items'       => 'Искать Проекты в работе',
		'not_found'          => 'Проекты в работе не найдены.',
		'not_found_in_trash' => 'В корзине нет проектов в работе.',
		'menu_name'          => 'Проекты в работе' 
	);
	$args   = array(
		'labels'      => $labels,
		'public'      => true,
		'menu_icon'   => 'dashicons-admin-multisite',
		'has_archive' => true,
		'supports'    => array( 'title', 'editor', 'thumbnail', 'category'  ),
		'taxonomies'  => array( 'post_tag','category' )
	);
	register_post_type( 'wprojects', $args );
}

function register_blog() {
	$labels = array(
		'name'               => 'Блоги',
		'singular_name'      => 'Блог',
		'add_new'            => 'Добавить блог',
		'add_new_item'       => 'Добавить новый блог',
		'edit_item'          => 'Редактировать блог',
		'new_item'           => 'Новый блог',
		'all_items'          => 'Все Блоги',
		'view_item'          => 'Просмотр блогов на сайте',
		'search_items'       => 'Искать блог',
		'not_found'          => 'Блоги не найдены.',
		'not_found_in_trash' => 'В корзине нет блогов.',
		'menu_name'          => 'Блог'
	);
	$args   = array(
		'labels'      => $labels,
		'public'      => true,
		'menu_icon'   => 'dashicons-excerpt-view',
		'has_archive' => true,
		'supports'    => array( 'title', 'editor', 'thumbnail', 'category'  ),
		'taxonomies'  => array( 'post_tag','category' )
	);
	register_post_type( 'blog', $args );
}
/// fix permalinks

function add_excerpt_to_pages()
{
	add_post_type_support( 'page', 'excerpt' );
}
add_action('init', 'add_excerpt_to_pages');

/// pagination
function kama_pagenavi( $before = '', $after = '', $echo = true, $args = array(), $wp_query = null ) {
	if ( ! $wp_query ) {
		global $wp_query;
	}
	if (pll_current_language('slug') === 'ru') {
		$default_args = array(
			'text_num_page'   => '',
			'num_pages'       => 10,
			'step_link'       => 10,
			'dotright_text'   => '…',
			'dotright_text2'  => '…',
			'back_text'       => 'Предыдущая',
			'next_text'       => 'Следующая',
			'first_page_text' => 'К началу',
			'last_page_text'  => 'В конец »',
		);
	} else {
		$default_args = array(
			'text_num_page'   => '',
			'num_pages'       => 10,
			'step_link'       => 10,
			'dotright_text'   => '…',
			'dotright_text2'  => '…',
			'back_text' => 'Назад',
			'next_text' => 'Далі',
			'first_page_text' => 'До початку',
			'last_page_text' => 'В кінець »',
		);
	}



	$default_args = apply_filters( 'kama_pagenavi_args', $default_args ); // чтобы можно было установить свои значения по умолчанию

	$args = array_merge( $default_args, $args );

	extract( $args );

	$posts_per_page = (int) $wp_query->query_vars['posts_per_page'];
	$paged          = (int) $wp_query->query_vars['paged'];
	$max_page       = $wp_query->max_num_pages;
	//проверка на надобность в навигации
	if ( $max_page <= 1 ) {
		return '';
	}

	if ( empty( $paged ) || $paged == 0 ) {
		$paged = 1;
	}

	$pages_to_show         = intval( $num_pages );
	$pages_to_show_minus_1 = $pages_to_show - 1;

	$half_page_start = floor( $pages_to_show_minus_1 / 2 ); //сколько ссылок до текущей страницы
	$half_page_end   = ceil( $pages_to_show_minus_1 / 2 ); //сколько ссылок после текущей страницы

	$start_page = $paged - $half_page_start; //первая страница
	$end_page   = $paged + $half_page_end; //последняя страница (условно)

	if ( $start_page <= 0 ) {
		$start_page = 1;
	}
	if ( ( $end_page - $start_page ) != $pages_to_show_minus_1 ) {
		$end_page = $start_page + $pages_to_show_minus_1;
	}
	if ( $end_page > $max_page ) {
		$start_page = $max_page - $pages_to_show_minus_1;
		$end_page   = (int) $max_page;
	}

	if ( $start_page <= 0 ) {
		$start_page = 1;
	}

	//выводим навигацию
	$out = '';

	// создаем базу чтобы вызвать get_pagenum_link один раз
	$link_base = str_replace( 99999999, '___', get_pagenum_link( 99999999 ) );
	$first_url = get_pagenum_link( 1 );
	if ( false === strpos( $first_url, '?' ) ) {
		$first_url = user_trailingslashit( $first_url );
	}

	$out .= $before . "<div class='pagination__inner'>\n";

	if ( $text_num_page ) {
		$text_num_page = preg_replace( '!{current}|{last}!', '%s', $text_num_page );
		$out           .= sprintf( "<span class='pages'>$text_num_page</span> ", $paged, $max_page );
	}
	// назад
	if ( $back_text && $paged != 1 ) {
		$out .= '<a class="prev" href="' . ( ( $paged - 1 ) == 1 ? $first_url : str_replace( '___', ( $paged - 1 ), $link_base ) ) . '">' . $back_text . '</a> ';
	}
	// в начало
	if ( $start_page >= 2 && $pages_to_show < $max_page ) {
		// $out .= '<a class="first" href="' . $first_url . '">' . ( $first_page_text ? $first_page_text : 1 ) . '</a> ';
		// if ( $dotright_text && $start_page != 2 ) {
		// 	$out .= '<span class="extend">' . $dotright_text . '</span> ';
		// }
	}
	// пагинация
	for ( $i = $start_page; $i <= $end_page; $i ++ ) {
		if ( $i == $paged ) {
			$out .= '<span class="pagination__current">' . $i . '</span> ';
		} elseif ( $i == 1 ) {
			$out .= '<a href="' . $first_url . '">1</a> ';
		} else {
			$out .= '<a href="' . str_replace( '___', $i, $link_base ) . '">' . $i . '</a> ';
		}
	}

	//ссылки с шагом
	$dd = 0;
	if ( $step_link && $end_page < $max_page ) {
		for ( $i = $end_page + 1; $i <= $max_page; $i ++ ) {
			if ( $i % $step_link == 0 && $i !== $num_pages ) {
				if ( ++ $dd == 1 ) {
					$out .= '<span class="extend">' . $dotright_text2 . '</span> ';
				}
				$out .= '<a href="' . str_replace( '___', $i, $link_base ) . '">' . $i . '</a> ';
			}
		}
	}
	// в конец
	if ( $end_page < $max_page ) {
		// if ( $dotright_text && $end_page != ( $max_page - 1 ) ) {
		// 	$out .= '<span class="extend">' . $dotright_text2 . '</span> ';
		// }
		// $out .= '<a class="last" href="' . str_replace( '___', $max_page, $link_base ) . '">' . ( $last_page_text ? $last_page_text : $max_page ) . '</a> ';
	}
	// вперед
	if ( $next_text && $paged != $end_page ) {
		$out .= '<a class="next" href="' . str_replace( '___', ( $paged + 1 ), $link_base ) . '">' . $next_text . '</a> ';
	}

	$out .= "</div>" . $after . "\n";

	$out = apply_filters( 'kama_pagenavi', $out );

	if ( $echo ) {
		return print $out;
	}

	return $out;
}





//////////////////////////////////////////////////////////////////////
///old project///


//Disable plugin updates
// add_filter( 'pre_site_transient_update_plugins', create_function( '$a', "return null;" ) ); // отключения обновления плагинов


// //Adding custom post types
// add_action( 'init', 'hellas_register_masters' );
// add_action( 'init', 'hellas_register_reviews' );
// add_action( 'init', 'hellas_register_services' );
// add_action( 'init', 'hellas_register_works' );

// function hellas_register_masters() {
// 	$labels = array(
// 		'name'               => 'Мастера',
// 		'singular_name'      => 'Мастер',
// 		'add_new'            => 'Добавить мастера',
// 		'add_new_item'       => 'Добавить нового мастера',
// 		'edit_item'          => 'Редактировать мастера',
// 		'new_item'           => 'Новый мастер',
// 		'all_items'          => 'Все мастера',
// 		'view_item'          => 'Просмотр врачей на сайте',
// 		'search_items'       => 'Искать мастера',
// 		'not_found'          => 'Мастера не найдено.',
// 		'not_found_in_trash' => 'В корзине нет мастеров.',
// 		'menu_name'          => 'Мастера'
// 	);
// 	$args   = array(
// 		'labels'        => $labels,
// 		'public'        => true,
// 		'menu_icon'     => 'dashicons-groups',
// 		'menu_position' => 5,
// 		'has_archive'   => false,
// 		'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments' ),
// 		'taxonomies'    => array( 'post_tag' )
// 	);
// 	register_post_type( 'master', $args );
// }



// function hellas_register_reviews() {
// 	$labels = array(
// 		'name'               => 'Отзывы',
// 		'singular_name'      => 'Отзыв',
// 		'add_new'            => 'Добавить отзыв',
// 		'add_new_item'       => 'Добавить новый отзыв',
// 		'edit_item'          => 'Редактировать отзыв',
// 		'new_item'           => 'Новый отзыв',
// 		'all_items'          => 'Все отзывы',
// 		'view_item'          => 'Просмотр отзывов на сайте',
// 		'search_items'       => 'Искать отзывы',
// 		'not_found'          => 'Отзывы не найдены.',
// 		'not_found_in_trash' => 'В корзине нет отзывов.',
// 		'menu_name'          => 'Отзывы'
// 	);
// 	$args   = array(
// 		'labels'      => $labels,
// 		'public'      => true,
// 		'menu_icon'   => 'dashicons-format-quote',
// 		'has_archive' => false,
// 		'supports'    => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
// 		'taxonomies'  => array( 'post_tag' )
// 	);
// 	register_post_type( 'review', $args );
// }

// function hellas_register_services() {
// 	$labels = array(
// 		'name'               => 'Услуги',
// 		'singular_name'      => 'Услуга',
// 		'add_new'            => 'Добавить услугу',
// 		'add_new_item'       => 'Добавить новую услугу',
// 		'edit_item'          => 'Редактировать услугу',
// 		'new_item'           => 'Новая услуга',
// 		'all_items'          => 'Все услуги',
// 		'view_item'          => 'Просмотр услуг на сайте',
// 		'search_items'       => 'Искать услуги',
// 		'not_found'          => 'Услуги не найдены.',
// 		'not_found_in_trash' => 'В корзине нет услуг.',
// 		'menu_name'          => 'Услуги'
// 	);
// 	$args   = array(
// 		'labels'      => $labels,
// 		'public'      => true,
// 		'menu_icon'   => 'dashicons-cart',
// 		'has_archive' => false,
// 		'supports'    => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
// 		'taxonomies'  => array( 'post_tag' )
// 	);
// 	register_post_type( 'service', $args );
// }

// function hellas_register_works() {
// 	$labels = array(
// 		'name'               => 'Работа',
// 		'singular_name'      => 'Работа',
// 		'add_new'            => 'Добавить работу',
// 		'add_new_item'       => 'Добавить новую работу',
// 		'edit_item'          => 'Редактировать работу',
// 		'new_item'           => 'Новая работа',
// 		'all_items'          => 'Все работы',
// 		'view_item'          => 'Просмотр работ на сайте',
// 		'search_items'       => 'Искать работы',
// 		'not_found'          => 'Работы не найдены.',
// 		'not_found_in_trash' => 'В корзине нет работ.',
// 		'menu_name'          => 'Наши работы'
// 	);
// 	$args   = array(
// 		'labels'      => $labels,
// 		'public'      => true,
// 		'menu_icon'   => 'dashicons-portfolio',
// 		'has_archive' => false,
// 		'supports'    => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
// 		'taxonomies'  => array( 'post_tag' )
// 	);
// 	register_post_type( 'work', $args );
// }



// //Reordering inputs in comments section
// add_filter( 'comment_form_fields', 'energy_reorder_comment_fields' );
// function energy_reorder_comment_fields( $fields ) {

// 	$new_fields = array();

// 	$myorder = array( 'author', 'email', 'comment' );

// 	foreach ( $myorder as $key ) {
// 		$new_fields[ $key ] = $fields[ $key ];
// 		unset( $fields[ $key ] );
// 	}

// 	return $new_fields;
// }

// //Cancelling redirect after comment post
// add_filter( 'comment_post_redirect', 'redirect_after_first_comment', 5, 2 );
// function redirect_after_first_comment( $url, $comment ) {
// 	$comment_count = get_comments(
// 		array(
// 			'author_email' => $comment->comment_author_email,
// 			'count'        => true
// 		)
// 	);
// 	if ( $comment_count == 1 ) {
// 		wp_redirect( '/' ); /* Сюда подставляете URL своей страницы приветствия */
// 		exit();
// 	}

// 	return $url = get_comment_link();
// }

// //Use separate templates for posts with diff category via its name
// add_filter( 'single_template', 'post_template' );
// function post_template( $the_template ) {
// 	foreach ( (array) get_the_category() as $cat ) {
// 		if ( file_exists( TEMPLATEPATH . "/single-{$cat->slug}.php" ) ) {
// 			return TEMPLATEPATH . "/single-{$cat->slug}.php";
// 		}
// 	}

// 	return $the_template;
// };

// function add_excerpt_to_pages()
// {
// 	add_post_type_support( 'page', 'excerpt' );
// }
// add_action('init', 'add_excerpt_to_pages');

// //Register nav menus
// add_action( 'after_setup_theme', function () {
// 	register_nav_menus( [
// 		'main'     => 'Меню в шапке',
// 	] );
// } );




// pll_register_string( '1', 'Ваше имя' );
// pll_register_string( '2', 'Консультация' );
// pll_register_string( '3', 'Наши услуги' );
// pll_register_string( '4', 'Предоставялем комплекс услуг для решения исходных задач' );
// pll_register_string( '5', 'Мы заботимся<br/> о наших клиентах' );
// pll_register_string( '6', 'Все услуги' );
// pll_register_string( '7', 'Все фото' );
// pll_register_string( '8', 'Наши Мастера' );
// pll_register_string( '9', 'Команда профессионалов с многолетним опытом работы' );
// pll_register_string( '10', 'Все Мастера' );
// pll_register_string( '11', 'О докторе' );
// pll_register_string( '12', 'Детская стоматология' );
// pll_register_string( '13', 'У нас есть все для <span class="bg-red">комфортного лечения</span> маленьких пациентов' );
// pll_register_string( '14', '<strong>Безконтактная</strong> и <strong>бесшумная</strong> технология лечения' );
// pll_register_string( '15', 'Прием <strong>без слез</strong> и <strong>истерик</strong>' );
// pll_register_string( '16', 'Комфортное лечение <strong>без боли</strong>' );
// pll_register_string( '17', '<strong>Внимательные</strong> и <strong>опытные</strong> специалисты' );
// pll_register_string( '18', 'Перейти к услугам' );
// pll_register_string( '19', 'цены' );
// pll_register_string( '20', 'Hellas Dental — это объединение самых современных технологий, методов лечения, оборудования и профессионализма сотрудников' );
// pll_register_string( '21', 'Смотреть все цены' );
// pll_register_string( '22', 'Стоимость:' );
// pll_register_string( '23', 'Оформить' );
// pll_register_string( '24', 'Отзывы' );
// pll_register_string( '25', 'Мы получаем множество благодарностей, вы рекомендуете нашу клинику своим друзьям и знакомым' );
// pll_register_string( '26', 'Все отзывы' );
// pll_register_string( '27', 'Читать полностью' );
// pll_register_string( '28', 'Стоматология' );
// pll_register_string( '29', 'Подробнее' );
// pll_register_string( '30', 'Блог' );
// pll_register_string( '31', 'Делимся полезными советами об уходе за зубами ' );
// pll_register_string( '32', 'Все статьи' );
// pll_register_string( '33', 'Одесса' );
// pll_register_string( '34', 'Читайте также:' );
// pll_register_string( '35', 'Запишитесь на консультацию' );
// pll_register_string( '36', 'Мы свяжемся с вами, подберем удобную клинику, время и подходящего врача.' );
// pll_register_string( '37', 'Главная' );
// pll_register_string( '38', 'Цены указаны без учета специальных предложений.' );
// pll_register_string( '39', 'Направление:' );
// pll_register_string( '40', 'Что сделано:' );
// pll_register_string( '41', 'Доктор:' );
// pll_register_string( '42', 'Смотреть видео' );
// pll_register_string( '43', 'Видео' );
// pll_register_string( '44', 'Оставить заявку' );
// pll_register_string( '45', 'До' );
// pll_register_string( '46', 'После' );
// pll_register_string( '47', 'Записаться на прием' );
// pll_register_string( '48', 'Чем поможет доктор' );
// pll_register_string( '49', 'Сертификаты и награды' );
// pll_register_string( '50', 'Что мы делаем' );
// pll_register_string( '51', 'Наши работы' );
// pll_register_string( '52', '<span class="blackened">О клинике</span> Hellas Dental' );
// pll_register_string( '53', 'Кто делает' );
// pll_register_string( '54', 'Контакты' );
// pll_register_string( '55', 'Галерея' );
// pll_register_string( '56', 'Оставить отзыв' );
// pll_register_string( '57', 'Введите текст отзыва' );
// pll_register_string( '58', 'Текст отзыва' );
// pll_register_string( '59', 'Введите Ваш E-mail' );
// pll_register_string( '60', 'Ваш E-mail' );
// pll_register_string( '61', 'Введите Ваше имя' );
// pll_register_string( '62', 'Ваше имя' );
// pll_register_string( '63', 'Наша гордость - это красивая улыбка наших клиентов!' );
// pll_register_string( '64', 'лет' );
// pll_register_string( '65', 'на рынке' );
// pll_register_string( '66', 'довольных клиента' );
// pll_register_string( '67', 'специализированных врачей' );
// pll_register_string( '68', 'услуг' );
// pll_register_string( '69', 'гарантии' );
// pll_register_string( 'address', 'пер. Вице-Адмирала Жукова 37а' );
// pll_register_string( '71', '© 2020 Стоматологическая клинника Hellas Dental.' );
// pll_register_string( '72', 'Сайт разработан' );


// function getPostViews( $postID ) {
// 	$count_key = 'post_views_count';
// 	$count     = get_post_meta( $postID, $count_key, true );
// 	if ( $count == '' ) {
// 		delete_post_meta( $postID, $count_key );
// 		add_post_meta( $postID, $count_key, '0' );

// 		return "0";
// 	}

// 	return $count;
// }

// function setPostViews( $postID ) {
// 	$count_key = 'post_views_count';
// 	$count     = get_post_meta( $postID, $count_key, true );
// 	if ( $count == '' ) {
// 		$count = 0;
// 		delete_post_meta( $postID, $count_key );
// 		add_post_meta( $postID, $count_key, '0' );
// 	} else {
// 		$count ++;
// 		update_post_meta( $postID, $count_key, $count );
// 	}
// }


// //Breadcrumbs
// function dimox_breadcrumbs() {
// 	$text_home = pll__( 'Главная' );

// 	/* === OPTIONS === */
// 	$text['home']     = $text_home; // text for the 'Home' link
// 	$text['category'] = 'Archive by Category "%s"'; // text for a category page
// 	$text['search']   = 'Search Results for "%s" Query'; // text for a search results page
// 	$text['tag']      = 'Posts Tagged "%s"'; // text for a tag page
// 	$text['author']   = 'Articles Posted by %s'; // text for an author page
// 	$text['404']      = 'Error 404'; // text for the 404 page
// 	$text['page']     = 'Page %s'; // text 'Page N'
// 	$text['cpage']    = 'Comment Page %s'; // text 'Comment Page N'

// 	$wrap_before = '<ul class="breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList">'; // the opening wrapper tag
// 	$wrap_after  = '</ul><!-- .breadcrumbs -->'; // the closing wrapper tag
// 	$sep         = '<span class="sep"> | </span>'; // separator between crumbs
// 	$before      = '<li class="breadcrumbs__item">'; // tag before the current crumb
// 	$after       = '</li>'; // tag after the current crumb

// 	$show_on_home   = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
// 	$show_home_link = 1; // 1 - show the 'Home' link, 0 - don't show
// 	$show_current   = 1; // 1 - show current page title, 0 - don't show
// 	$show_last_sep  = 1; // 1 - show last separator, when current page title is not displayed, 0 - don't show
// 	/* === END OF OPTIONS === */

// 	global $post;
// 	$home_url  = home_url( '/' );
// 	$link      = '<li class="breadcrumbs__item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">';
// 	$link      .= '<a href="%1$s" itemprop="item"><span itemprop="name">%2$s</span></a>';
// 	$link      .= '<meta itemprop="position" content="%3$s" />';
// 	$link      .= '</li>';
// 	$parent_id = ( $post ) ? $post->post_parent : '';
// 	$home_link = sprintf( $link, $home_url, $text['home'], 1 );

// 	if ( is_home() || is_front_page() ) {

// 		if ( $show_on_home ) {
// 			echo $wrap_before . $home_link . $wrap_after;
// 		}

// 	} else {

// 		$position = 0;

// 		echo $wrap_before;

// 		if ( $show_home_link ) {
// 			$position += 1;
// 			echo $home_link;
// 		}

// 		if ( is_category() ) {
// 			$parents = get_ancestors( get_query_var( 'cat' ), 'category' );
// 			foreach ( array_reverse( $parents ) as $cat ) {
// 				$position += 1;
// 				if ( $position > 1 ) {
// 					echo $sep;
// 				}
// 				echo sprintf( $link, get_category_link( $cat ), get_cat_name( $cat ), $position );
// 			}
// 			if ( get_query_var( 'paged' ) ) {
// 				$position += 1;
// 				$cat      = get_query_var( 'cat' );
// 				echo $sep . sprintf( $link, get_category_link( $cat ), get_cat_name( $cat ), $position );
// 				echo $sep . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
// 			} else {
// 				if ( $show_current ) {
// 					if ( $position >= 1 ) {
// 						echo $sep;
// 					}
// 					echo $before . sprintf( $text['category'], single_cat_title( '', false ) ) . $after;
// 				} elseif ( $show_last_sep ) {
// 					echo $sep;
// 				}
// 			}

// 		} elseif ( is_search() ) {
// 			if ( get_query_var( 'paged' ) ) {
// 				$position += 1;
// 				if ( $show_home_link ) {
// 					echo $sep;
// 				}
// 				echo sprintf( $link, $home_url . '?s=' . get_search_query(), sprintf( $text['search'], get_search_query() ), $position );
// 				echo $sep . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
// 			} else {
// 				if ( $show_current ) {
// 					if ( $position >= 1 ) {
// 						echo $sep;
// 					}
// 					echo $before . sprintf( $text['search'], get_search_query() ) . $after;
// 				} elseif ( $show_last_sep ) {
// 					echo $sep;
// 				}
// 			}

// 		} elseif ( is_year() ) {
// 			if ( $show_home_link && $show_current ) {
// 				echo $sep;
// 			}
// 			if ( $show_current ) {
// 				echo $before . get_the_time( 'Y' ) . $after;
// 			} elseif ( $show_home_link && $show_last_sep ) {
// 				echo $sep;
// 			}

// 		} elseif ( is_month() ) {
// 			if ( $show_home_link ) {
// 				echo $sep;
// 			}
// 			$position += 1;
// 			echo sprintf( $link, get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ), $position );
// 			if ( $show_current ) {
// 				echo $sep . $before . get_the_time( 'F' ) . $after;
// 			} elseif ( $show_last_sep ) {
// 				echo $sep;
// 			}

// 		} elseif ( is_day() ) {
// 			if ( $show_home_link ) {
// 				echo $sep;
// 			}
// 			$position += 1;
// 			echo sprintf( $link, get_year_link( get_the_time( 'Y' ) ), get_the_time( 'Y' ), $position ) . $sep;
// 			$position += 1;
// 			echo sprintf( $link, get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ), get_the_time( 'F' ), $position );
// 			if ( $show_current ) {
// 				echo $sep . $before . get_the_time( 'd' ) . $after;
// 			} elseif ( $show_last_sep ) {
// 				echo $sep;
// 			}

// 		} elseif ( is_single() && ! is_attachment() ) {
// 			if ( get_post_type() != 'post' ) {
// 				$position  += 1;
// 				$post_type = get_post_type_object( get_post_type() );
// 				if ( $position > 1 ) {
// 					echo $sep;
// 				}
// 				echo sprintf( $link, get_post_type_archive_link( $post_type->name ), $post_type->labels->name, $position );
// 				if ( $show_current ) {
// 					echo $sep . $before . get_the_title() . $after;
// 				} elseif ( $show_last_sep ) {
// 					echo $sep;
// 				}
// 			} else {
// 				$cat       = get_the_category();
// 				$catID     = $cat[0]->cat_ID;
// 				$parents   = get_ancestors( $catID, 'category' );
// 				$parents   = array_reverse( $parents );
// 				$parents[] = $catID;
// 				foreach ( $parents as $cat ) {
// 					$position += 1;
// 					if ( $position > 1 ) {
// 						echo $sep;
// 					}
// 					echo sprintf( $link, get_category_link( $cat ), get_cat_name( $cat ), $position );
// 				}
// 				if ( get_query_var( 'cpage' ) ) {
// 					$position += 1;
// 					echo $sep . sprintf( $link, get_permalink(), get_the_title(), $position );
// 					echo $sep . $before . sprintf( $text['cpage'], get_query_var( 'cpage' ) ) . $after;
// 				} else {
// 					if ( $show_current ) {
// 						echo $sep . $before . get_the_title() . $after;
// 					} elseif ( $show_last_sep ) {
// 						echo $sep;
// 					}
// 				}
// 			}

// 		} elseif ( is_post_type_archive() ) {
// 			$post_type = get_post_type_object( get_post_type() );
// 			if ( get_query_var( 'paged' ) ) {
// 				$position += 1;
// 				if ( $position > 1 ) {
// 					echo $sep;
// 				}
// 				echo sprintf( $link, get_post_type_archive_link( $post_type->name ), $post_type->label, $position );
// 				echo $sep . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
// 			} else {
// 				if ( $show_home_link && $show_current ) {
// 					echo $sep;
// 				}
// 				if ( $show_current ) {
// 					echo $before . $post_type->label . $after;
// 				} elseif ( $show_home_link && $show_last_sep ) {
// 					echo $sep;
// 				}
// 			}

// 		} elseif ( is_attachment() ) {
// 			$parent    = get_post( $parent_id );
// 			$cat       = get_the_category( $parent->ID );
// 			$catID     = $cat[0]->cat_ID;
// 			$parents   = get_ancestors( $catID, 'category' );
// 			$parents   = array_reverse( $parents );
// 			$parents[] = $catID;
// 			foreach ( $parents as $cat ) {
// 				$position += 1;
// 				if ( $position > 1 ) {
// 					echo $sep;
// 				}
// 				echo sprintf( $link, get_category_link( $cat ), get_cat_name( $cat ), $position );
// 			}
// 			$position += 1;
// 			echo $sep . sprintf( $link, get_permalink( $parent ), $parent->post_title, $position );
// 			if ( $show_current ) {
// 				echo $sep . $before . get_the_title() . $after;
// 			} elseif ( $show_last_sep ) {
// 				echo $sep;
// 			}

// 		} elseif ( is_page() && ! $parent_id ) {
// 			if ( $show_home_link && $show_current ) {
// 				echo $sep;
// 			}
// 			if ( $show_current ) {
// 				echo $before . get_the_title() . $after;
// 			} elseif ( $show_home_link && $show_last_sep ) {
// 				echo $sep;
// 			}

// 		} elseif ( is_page() && $parent_id ) {
// 			$parents = get_post_ancestors( get_the_ID() );
// 			foreach ( array_reverse( $parents ) as $pageID ) {
// 				$position += 1;
// 				if ( $position > 1 ) {
// 					echo $sep;
// 				}
// 				echo sprintf( $link, get_page_link( $pageID ), get_the_title( $pageID ), $position );
// 			}
// 			if ( $show_current ) {
// 				echo $sep . $before . get_the_title() . $after;
// 			} elseif ( $show_last_sep ) {
// 				echo $sep;
// 			}

// 		} elseif ( is_tag() ) {
// 			if ( get_query_var( 'paged' ) ) {
// 				$position += 1;
// 				$tagID    = get_query_var( 'tag_id' );
// 				echo $sep . sprintf( $link, get_tag_link( $tagID ), single_tag_title( '', false ), $position );
// 				echo $sep . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
// 			} else {
// 				if ( $show_home_link && $show_current ) {
// 					echo $sep;
// 				}
// 				if ( $show_current ) {
// 					echo $before . sprintf( $text['tag'], single_tag_title( '', false ) ) . $after;
// 				} elseif ( $show_home_link && $show_last_sep ) {
// 					echo $sep;
// 				}
// 			}

// 		} elseif ( is_author() ) {
// 			$author = get_userdata( get_query_var( 'author' ) );
// 			if ( get_query_var( 'paged' ) ) {
// 				$position += 1;
// 				echo $sep . sprintf( $link, get_author_posts_url( $author->ID ), sprintf( $text['author'], $author->display_name ), $position );
// 				echo $sep . $before . sprintf( $text['page'], get_query_var( 'paged' ) ) . $after;
// 			} else {
// 				if ( $show_home_link && $show_current ) {
// 					echo $sep;
// 				}
// 				if ( $show_current ) {
// 					echo $before . sprintf( $text['author'], $author->display_name ) . $after;
// 				} elseif ( $show_home_link && $show_last_sep ) {
// 					echo $sep;
// 				}
// 			}

// 		} elseif ( is_404() ) {
// 			if ( $show_home_link && $show_current ) {
// 				echo $sep;
// 			}
// 			if ( $show_current ) {
// 				echo $before . $text['404'] . $after;
// 			} elseif ( $show_last_sep ) {
// 				echo $sep;
// 			}

// 		} elseif ( has_post_format() && ! is_singular() ) {
// 			if ( $show_home_link && $show_current ) {
// 				echo $sep;
// 			}
// 			echo get_post_format_string( get_post_format() );
// 		}

// 		echo $wrap_after;

// 	}
// }

// //Customizer
// add_action( 'customize_register', function ( $customizer ) {

// 	$customizer->add_section(
// 		'contacts',
// 		array(
// 			'title'    => 'Контактные данные',
// 			'priority' => 11,
// 		)
// 	);
//  	$customizer->add_setting(
// 		'work-time-1',
// 		array( 'default' => '-' )
// 	);
// 	$customizer->add_setting(
// 		'work-time-2',
// 		array( 'default' => '-' )
// 	);
// 	$customizer->add_setting(
// 		'work-time-3',
// 		array( 'default' => '-' )
// 	);
// 	$customizer->add_setting(
// 		'phone-1',
// 		array( 'default' => '#' )
// 	);
// 	$customizer->add_setting(
// 		'email',
// 		array( 'default' => '#' )
// 	);
// 	$customizer->add_setting(
// 		'facebook',
// 		array( 'default' => '-' )
// 	);
// 	$customizer->add_setting(
// 		'instagram',
// 		array( 'default' => '-' )
// 	);
// 	$customizer->add_setting(
// 		'youtube',
// 		array( 'default' => '-' )
// 	);
// 	$customizer->add_setting(
// 		'linkedin',
// 		array( 'default' => '#' )
// 	);
// 	$customizer->add_setting(
// 		'telegram',
// 		array( 'default' => '@' )
// 	);
// 	//////////////////////////////
	 
// 	$customizer->add_control(
// 		'work-time-1',
// 		array(
// 			'label'   => 'Рабочее время пн-пт',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'work-time-2',
// 		array(
// 			'label'   => 'Рабочее время сб',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'work-time-3',
// 		array(
// 			'label'   => 'Рабочее время вс',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
	

// 	$customizer->add_control(
// 		'phone-1',
// 		array(
// 			'label'   => 'Номер телефона',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'email',
// 		array(
// 			'label'   => 'E-Mail',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'facebook',
// 		array(
// 			'label'   => 'Ссылка на Facebook',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'instagram',
// 		array(
// 			'label'   => 'Ссылка на Instagram',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'telegram',
// 		array(
// 			'label'   => 'Telegram',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'linkedin',
// 		array(
// 			'label'   => 'Ссылка на LinkedIn',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);
// 	$customizer->add_control(
// 		'youtube',
// 		array(
// 			'label'   => 'Ссылка на YouTube',
// 			'section' => 'contacts',
// 			'type'    => 'text',
// 		)
// 	);

// } );

// /**
//  * Альтернатива wp_pagenavi. Создает ссылки пагинации на страницах архивов.
//  *
//  * @param string $before - текст до навигации
//  * @param string $after - текст после навигации
//  * @param bool $echo - возвращать или выводить результат
//  * @param array $args - аргументы функции
//  * @param array $wp_query - объект WP_Query на основе которого строится пагинация. По умолчанию глобальная переменная $wp_query
// */
// function kama_pagenavi( $before = '', $after = '', $echo = true, $args = array(), $wp_query = null ) {
// 	if ( ! $wp_query ) {
// 		global $wp_query;
// 	}

// 	if (pll_current_language('slug') === 'ru') {
// 		$svg_next = '<svg width="25" height="16" viewBox="0 0 25 16" fill="none" xmlns="http://www.w3.org/2000/svg">
// 		<path d="M24.7071 8.70711C25.0976 8.31658 25.0976 7.68342 24.7071 7.29289L18.3431 0.928932C17.9526 0.538408 17.3195 0.538408 16.9289 0.928932C16.5384 1.31946 16.5384 1.95262 16.9289 2.34315L22.5858 8L16.9289 13.6569C16.5384 14.0474 16.5384 14.6805 16.9289 15.0711C17.3195 15.4616 17.9526 15.4616 18.3431 15.0711L24.7071 8.70711ZM0 9H24V7H0V9Z" >
// 		</svg>
// 		';
// 		$svg_pref = '<svg width="25" height="16" viewBox="0 0 25 16" fill="none" xmlns="http://www.w3.org/2000/svg">
// 		<path d="M0.292892 7.29289C-0.0976315 7.68342 -0.0976315 8.31658 0.292892 8.70711L6.65685 15.0711C7.04738 15.4616 7.68054 15.4616 8.07107 15.0711C8.46159 14.6805 8.46159 14.0474 8.07107 13.6569L2.41421 8L8.07107 2.34315C8.46159 1.95262 8.46159 1.31946 8.07107 0.928932C7.68054 0.538408 7.04738 0.538408 6.65685 0.928932L0.292892 7.29289ZM25 7H1V9H25V7Z" />
// 		</svg>
// 		';
// 		$default_args = array(
// 			'text_num_page'   => '',
// 			'num_pages'       => 10,
// 			'step_link'       => 10,
// 			'dotright_text'   => '…',
// 			'dotright_text2'  => '…',
// 			'back_text'       => $svg_pref,
// 			'next_text'       => $svg_next,
// 			'first_page_text' => 'К началу',
// 			'last_page_text'  => 'В конец »',
// 		);
// 	} else {
// 		$default_args = array(
// 			'text_num_page'   => '',
// 			'num_pages'       => 10,
// 			'step_link'       => 10,
// 			'dotright_text'   => '…',
// 			'dotright_text2'  => '…',
// 			'back_text'       => $svg_pref,
// 			'next_text'       => $svg_next,
// 			'first_page_text' => 'Beginning',
// 			'last_page_text'  => 'End',
// 		);
// 	}



// 	$default_args = apply_filters( 'kama_pagenavi_args', $default_args ); // чтобы можно было установить свои значения по умолчанию

// 	$args = array_merge( $default_args, $args );

// 	extract( $args );

// 	$posts_per_page = (int) $wp_query->query_vars['posts_per_page'];
// 	$paged          = (int) $wp_query->query_vars['paged'];
// 	$max_page       = $wp_query->max_num_pages;

// 	//проверка на надобность в навигации
// 	if ( $max_page <= 1 ) {
// 		return false;
// 	}

// 	if ( empty( $paged ) || $paged == 0 ) {
// 		$paged = 1;
// 	}

// 	$pages_to_show         = intval( $num_pages );
// 	$pages_to_show_minus_1 = $pages_to_show - 1;

// 	$half_page_start = floor( $pages_to_show_minus_1 / 2 ); //сколько ссылок до текущей страницы
// 	$half_page_end   = ceil( $pages_to_show_minus_1 / 2 ); //сколько ссылок после текущей страницы

// 	$start_page = $paged - $half_page_start; //первая страница
// 	$end_page   = $paged + $half_page_end; //последняя страница (условно)

// 	if ( $start_page <= 0 ) {
// 		$start_page = 1;
// 	}
// 	if ( ( $end_page - $start_page ) != $pages_to_show_minus_1 ) {
// 		$end_page = $start_page + $pages_to_show_minus_1;
// 	}
// 	if ( $end_page > $max_page ) {
// 		$start_page = $max_page - $pages_to_show_minus_1;
// 		$end_page   = (int) $max_page;
// 	}

// 	if ( $start_page <= 0 ) {
// 		$start_page = 1;
// 	}

// 	//выводим навигацию
// 	$out = '';

// 	// создаем базу чтобы вызвать get_pagenum_link один раз
// 	$link_base = str_replace( 99999999, '___', get_pagenum_link( 99999999 ) );
// 	$first_url = get_pagenum_link( 1 );
// 	if ( false === strpos( $first_url, '?' ) ) {
// 		$first_url = user_trailingslashit( $first_url );
// 	}

// 	$out .= $before . "<div class='pagination__inner'>\n";

// 	if ( $text_num_page ) {
// 		$text_num_page = preg_replace( '!{current}|{last}!', '%s', $text_num_page );
// 		$out           .= sprintf( "<span class='pages'>$text_num_page</span> ", $paged, $max_page );
// 	}
// 	// назад
// 	if ( $back_text && $paged != 1 ) {
// 		$out .= '<a class="prev" href="' . ( ( $paged - 1 ) == 1 ? $first_url : str_replace( '___', ( $paged - 1 ), $link_base ) ) . '">' . $back_text . '</a> ';
// 	}
// 	// в начало
// 	if ( $start_page >= 2 && $pages_to_show < $max_page ) {
// 		$out .= '<a class="first" href="' . $first_url . '">' . ( $first_page_text ? $first_page_text : 1 ) . '</a> ';
// 		if ( $dotright_text && $start_page != 2 ) {
// 			$out .= '<span class="extend">' . $dotright_text . '</span> ';
// 		}
// 	}
// 	// пагинация
// 	for ( $i = $start_page; $i <= $end_page; $i ++ ) {
// 		if ( $i == $paged ) {
// 			$out .= '<span class="pagination__current">' . $i . '</span> ';
// 		} elseif ( $i == 1 ) {
// 			$out .= '<a href="' . $first_url . '">1</a> ';
// 		} else {
// 			$out .= '<a href="' . str_replace( '___', $i, $link_base ) . '">' . $i . '</a> ';
// 		}
// 	}

// 	//ссылки с шагом
// 	$dd = 0;
// 	if ( $step_link && $end_page < $max_page ) {
// 		for ( $i = $end_page + 1; $i <= $max_page; $i ++ ) {
// 			if ( $i % $step_link == 0 && $i !== $num_pages ) {
// 				if ( ++ $dd == 1 ) {
// 					$out .= '<span class="extend">' . $dotright_text2 . '</span> ';
// 				}
// 				$out .= '<a href="' . str_replace( '___', $i, $link_base ) . '">' . $i . '</a> ';
// 			}
// 		}
// 	}
// 	// в конец
// 	if ( $end_page < $max_page ) {
// 		if ( $dotright_text && $end_page != ( $max_page - 1 ) ) {
// 			$out .= '<span class="extend">' . $dotright_text2 . '</span> ';
// 		}
// 		$out .= '<a class="last" href="' . str_replace( '___', $max_page, $link_base ) . '">' . ( $last_page_text ? $last_page_text : $max_page ) . '</a> ';
// 	}
// 	// вперед
// 	if ( $next_text && $paged != $end_page ) {
// 		$out .= '<a class="next" href="' . str_replace( '___', ( $paged + 1 ), $link_base ) . '">' . $next_text . '</a> ';
// 	}

// 	$out .= "</div>" . $after . "\n";

// 	$out = apply_filters( 'kama_pagenavi', $out );

// 	if ( $echo ) {
// 		return print $out;
// 	}

// 	return $out;
// }
