<div class="wrapper">
    <?php
    $posts_per_page = $wp_query->query_vars['posts_per_page'];
    $email = get_theme_mod('email');
    $phone = get_theme_mod('phone');
    get_header(); ?>
    <main class="main portfolio">
        <?php
            $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
            if (file_exists($breadcrumbs)) {
                $customLastPage = pll__('projects_page');
                include $breadcrumbs;
            } else {
                echo 'Файл breadcrumbs.php не найден';
            }
        ?>

        <div class="portfolio__top">
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-md-6">
                        <p class="section__title">
                            <?php
                               echo pll__('projects_in-work_title')
                            ?>
                        </p>
                        <p class="section__descr">
                            <?php
                               echo pll__('projects_in-work_subtitle')
                            ?>
                        </p>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="tab__list">
                            <?php
                                // таб "все" 
                                $current_category = (isset($_GET['category'])) ? $_GET['category'] : '';
                                $tag = array(
                                    'link' => esc_url(remove_query_arg('category')),
                                    'active' => empty($current_category) ? 'active' : '',
                                    'name' => pll__('tab_all')
                                );

                                $tab_part = get_template_directory() . '/parts/tab.php';
                                if (file_exists($tab_part)) {
                                    include $tab_part;
                                } else {
                                    echo 'Файл tab.php не найден';
                                }
                                // fin таб "все"
                                $args = array(
                                    'post_type'      => 'wprojects',
                                    'posts_per_page' => $posts_per_page,
                                    'paged'          => $paged,
                                );

                                $query = new WP_Query($args);
                                $categories = get_categories();
                                
                                foreach ($categories as $category) {
                                    $tag = array(
                                        'link'   => esc_url(add_query_arg('category', $category->slug)),
                                        'active' => ($category->slug == $current_category) ? 'active' : '',
                                        'name'   => esc_html($category->name),
                                    );
                                    $tab_part = get_template_directory() . '/parts/tab.php';
                                    if (file_exists($tab_part)) {
                                        include $tab_part;
                                    } else {
                                        echo 'Файл tab.php не найден';
                                    }
                                }
                            ?>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <section style="padding-bottom: 0">
            <div class="container">
                    <?php
                        $args = array(
                            'post_type'      => 'wprojects',  // Замените на ваш тип записей
                            'post_status'    => 'publish',
                            'posts_per_page' => $posts_per_page,
                            'paged'          => $paged
                        );
                        if (!empty($current_category)) {
                            $args['category_name'] = $current_category;
                        }
                        $new_query = new WP_Query($args);

                        $middlePoster = get_field('middlePoster');
                        $harakteristiki = get_field('harakteristiki');
                        $korotkoe_opisanie = get_field('korotkoe_opisanie');
                        if ( $new_query->have_posts() ) :
                            $first_post = true;
                            while ($query->have_posts()) : $query->the_post();
                            $categ = get_the_category();
                    ?>
                        <div class="row">
                            <div class="portfolio-card<?php echo $first_post ? ' portfolio-card__top-first' : '';?>">
                                <?php if (!empty($categ)) { ?>
                                <div class="portfolio-card__top">
                                    <?php echo $categ[0]->name ?>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <?php if (!empty($middlePoster)) { ?>
                                <div class="portfolio-card__middle">
                                    <img src="<?php echo $middlePoster ?>" alt="<?php the_title(); ?>">
                                </div>
                                <?php } ?>
                            </div>
                            <div class="col-12 offset-lg-1 col-lg-5 d-flex align-items-center">
                                <div class="portfolio-card__text">
                                    <div class="portfolio-card__har">
                                        
                                        <?php
                                            if (!empty($harakteristiki)) {
                                                foreach ($harakteristiki as $har) {
                                                    $title = $har['title'];
                                                    $value = $har['value'];
                                                    $unit = $har['unit'];
                                        ?>
                                            <div class="portfolio-card__har-item">
                                                <div class="portfolio-card__har-title">
                                                    <?php
                                                        echo $title
                                                    ?>
                                                </div>
                                                <div class="portfolio-card__har-value">
                                                    <?php
                                                        echo $value . ' ' . $unit;
                                                    ?>
                                                </div>
                                            </div>
                                        <?php
                                                }
                                            }
                                        ?>
                                    </div>
                                    <div class="portfolio-card__about">
                                        <p class="portfolio-card__about-title">
                                            <?php
                                                echo pll__('projects_about')
                                            ?>:
                                        </p>
                                        <div class="portfolio-card__about-descr">
                                            <?php
                                                echo $korotkoe_opisanie
                                            ?>
                                        </div>
                                    </div>
                                    <a class="portfolio-card__button button button_size_large button_color_black button_type_icon" href="<?php echo get_permalink() ?>">
                                        <?php echo pll__('read more');?>
                                        <svg><use href="#icon-arrow-right"></use></svg>
                                    </a>
                                </div>
                            </div>
                        </div>    
                    <?php
                        $first_post = false;
                        endwhile;
                    ?>
                
            </div>
        </section>
        <section>
            <div class="container">
                <?php 
                    kama_pagenavi($before = '', $after = '', $echo = true, $args = array(), $wp_query = $new_query);
                ?>
                <?php 
                    wp_reset_postdata();
                    endif; 
                ?>
            </div>
        </section>
        <section class="portfolio-bform">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-5 d-flex align-items-center">
                        <div class="bform__cont">
                            <div class="section__title">
                                <?php
                                    echo pll__('form_title')
                                ?>
                            </div>
                           
                            <p class="portfolio-bform__text"> <?php echo $email ?> <p>
                            <p class="portfolio-bform__text"> <?php echo $phone ?> <p>
                        </div>
                    </div>
                    <div class="col-12 offset-lg-1 col-lg-6 d-flex align-items-center">
                        <div style="width: 100%">
                            <p class="portfolio-bform__simp-p">
                                <?php
                                    echo pll__('form_descr')
                                ?>
                            </p>
                            <?php
                                $simpleForm = get_template_directory() . '/parts/simpleForm.php';
                                if (file_exists($simpleForm)) {
                                    $bform = array(
                                        array(
                                            'acf_fc_layout' => 'input',
                                            'name' => 'email',
                                            'placeholder' => pll__('form_emael_placeholder')
                                        ),
                                    );
                                    $btitle = pll__('form_title')
                                    include $simpleForm;
                                } else {
                                    echo 'Файл simpleForm.php не найден';
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php get_footer(); ?>

