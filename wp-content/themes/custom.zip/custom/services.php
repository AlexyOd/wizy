    <div class="wrapper">
    <?php
    /*Template Name: Услуги*/
    $title = get_field('title');
    $subtitle = get_field('subtitle');
    $poster = get_field('poster');
    get_header(); ?>
    <main class="main services">
        <?php
            $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
            if (file_exists($breadcrumbs)) {
                include $breadcrumbs;
            } else {
                echo 'Файл breadcrumbs.php не найден';
            }
        ?>

        <?php
            $top_image = get_template_directory() . '/parts/top_image.php';
            if (file_exists($top_image)) {
                $main_bg = get_field('poster');
                include $top_image;
            } else {
                echo 'Файл top_image.php не найден';
            }
        ?>
        <section>
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-md-6 d-flex align-items-center">
                        <p class="section__title">
                            <?php
                                echo $title
                            ?>
                        </p>
                    </div>
                    <div class="col-12 col-md-6 d-flex align-items-center">
                        <p class="section__descr">
                            <?php
                                echo $subtitle
                            ?>
                        </p>
                    </div>
                </div> 
                
                <?php
                    $services = get_field('services');
                    
                     foreach ( $services as $service ) {
                         $serviceId=$service['service']->ID;
                         $miniature = get_field('miniature', $serviceId);
                         $poster = $miniature['poster'];
                         $mTitle = $miniature['title'];
                         $mDesrc = $miniature['desrc'];
                         $link = get_permalink($serviceId);
                ?>
                    
                    <div class="row service-mini__item">
                        <div class="col-12 col-lg-7 service-mini__left d-flex align-items-center">
                            <img src="<?php echo $poster ?>" alt="<?php echo $mTitle ?>">
                        </div>
                        <div class="col-12 col-lg-7 service-mini__right d-flex align-items-center">
                            <div class="service-mini__item-text">
                                <div class="service-mini__item-title">
                                    <?php
                                        echo $mTitle
                                    ?>
                                </div>
                                <div class="service-mini__item-descr">
                                    <?php
                                        echo $mDesrc
                                    ?>
                                </div>
                                <a href="<?php echo $link ?>" class="service-mini__item-link button button_size_large  button_color_black button_type_icon">
                                    <?php
                                        echo pll__('read more')
                                    ?>
                                        <svg><use href="#icon-arrow-right"></use></svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                <?php
                    }
                ?>

            </div>
        </section>

        
    </main>
    </div>

    <?php get_footer(); ?>
