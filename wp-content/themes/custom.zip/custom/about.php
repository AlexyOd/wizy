<div class="wrapper">
    <?php
    /*
    Template Name: О нас
    */
    get_header(); ?>
    <main class="main">
        <?php
            $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
            if (file_exists($breadcrumbs)) {
                include $breadcrumbs;
            } else {
                echo 'Файл breadcrumbs.php не найден';
            }
        ?>

        <?php
            $top_image = get_template_directory() . '/parts/top_image.php';
            if (file_exists($top_image)) {
                $main_bg = get_field('banner');
                include $top_image;
            } else {
                echo 'Файл top_image.php не найден';
            }
        ?>

        <?php
            $about_history = get_template_directory() . '/parts/about_history.php';
            if (file_exists($about_history)) {
                include $about_history;
            } else {
                echo 'Файл about_history.php не найден';
            }
        ?>

        
    </main>
</div>
<?php get_footer(); ?>

