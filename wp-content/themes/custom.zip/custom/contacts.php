<div class="wrapper">
    <?php
    /*
    Template Name: Контакты
    */
    $title = get_field('title');
    $subtitle = get_field('subtitle');
    $form = get_field('form');
    $cinfo = get_field('cinfo');
    $linkedin = get_theme_mod('linkedin');
    $instagram = get_theme_mod('instagram');
    $facebook = get_theme_mod('facebook');
    $tiktok = get_theme_mod('tiktok');
    $email = get_theme_mod('email');
    $phone = get_theme_mod('phone');

    get_header(); ?>
    <main class="main">
        <?php
            $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
            if (file_exists($breadcrumbs)) {
                include $breadcrumbs;
            } else {
                echo 'Файл breadcrumbs.php не найден';
            }
        ?>
        <section class="contacts">
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-md-6">
                        <p class="section__title">
                            <?php
                                echo $title
                            ?>
                        </p>
                    </div>
                    <div class="col-12 col-md-6">
                        <p class="section__descr">
                            <?php
                                echo $subtitle
                            ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="contacts__cont">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-lg-7 d-flex">
                            <div class="contacts__form">
                                <?php
                                    $ftitle = $form['title']
                                ?>
                                <p class="contacts__form-title">
                                    <?php echo $ftitle ?>
                                </p>

                                <?php
                                    $simpleForm = get_template_directory() . '/parts/simpleForm.php';
                                    if (file_exists($simpleForm)) {
                                        $bform = $form['fields'];
                                        $btitle = $ftitle
                                        include $simpleForm;
                                    } else {
                                        echo 'Файл simpleForm.php не найден';
                                    }
                                ?>
                                
                            </div>
                        </div>
                        <div class="col-12 col-lg-5 d-flex">
                            <div class="contacts__info">
                                <div class="contacts__info-title">
                                    <?php echo pll__('contact_info_title');?>
                                </div>
                                <div class="contacts__info-cont">
                                    <?php
                                        foreach ($cinfo['info'] as $item) {
                                            $type = $item['acf_fc_layout'];
                                    ?>
                                        <?php
                                            if ($type == 'address') {
                                                $icon = $item['svg'];
                                                $text = $item['text'];
                                                $link = $item['link'];
                                        ?>
                                            <a hjref="<?php echo $link ?>" class="contacts__info-item">
                                                <div class="contacts__info-item-icon">
                                                    <?php
                                                        echo $icon
                                                    ?>
                                                </div>
                                                <div class="contacts__info-item-text">
                                                    <?php
                                                        echo $text
                                                    ?>
                                                </div>
                                            </a>
                                        <?php
                                            }
                                        ?>
                                        <?php
                                            if ($type == 'phone') {
                                                $icon = $item['svg'];
                                                $tel = $item['tel'];
                                        ?>
                                            <a hjref="tel:<?php echo $tel ?>" class="contacts__info-item">
                                                <div class="contacts__info-item-icon">
                                                    <?php
                                                        echo $icon
                                                    ?>
                                                </div>
                                                <div class="contacts__info-item-text">
                                                    <?php
                                                        echo $tel
                                                    ?>
                                                </div>
                                            </a>
                                        <?php
                                            }
                                        ?>
                                         <?php
                                            if ($type == 'email') {
                                                $icon = $item['svg'];
                                                $email = $item['email'];
                                        ?>
                                            <a hjref="mailto:<?php echo $email ?>" class="contacts__info-item">
                                                <div class="contacts__info-item-icon">
                                                    <?php
                                                        echo $icon
                                                    ?>
                                                </div>
                                                <div class="contacts__info-item-text">
                                                    <?php
                                                        echo $email
                                                    ?>
                                                </div>
                                            </a>
                                        <?php
                                            }
                                        ?>
                                    <?php
                                        }
                                    ?>
                                </div>
                                <div class="contacts__info-social">
                                    <ul class="footer-social">
                                        <?php if($phone):?>
                                        <li>
                                            <a href="<?php echo $phone;?>" title="<?php echo $phone;?>">
                                            <svg class="icon">
                                                <use href="#icon-phone"></use>
                                            </svg>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if($linkedin):?>
                                        <li>
                                            <a href="<?php echo $linkedin;?>" title="<?php echo $linkedin;?>">
                                            <svg class="icon">
                                                <use href="#icon-linkedin"></use>
                                            </svg>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if($instagram):?>
                                        <li>
                                            <a href="<?php echo $instagram;?>" title="<?php echo $instagram;?>">
                                            <svg class="icon">
                                                <use href="#icon-instagram"></use>
                                            </svg>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if($facebook):?>
                                        <li>
                                            <a href="<?php echo $facebook;?>" title="<?php echo $facebook;?>">
                                            <svg class="icon">
                                                <use href="#icon-facebook"></use>
                                            </svg>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if($tiktok):?>
                                        <li>
                                            <a href="<?php $tiktok;?>" title="<?php echo $tiktok;?>">
                                            <svg class="icon">
                                                <use href="#icon-tiktok"></use>
                                            </svg>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if($email):?>
                                        <li>
                                            <a href="<?php $email;?>" title="<?php echo $email;?>">
                                            <svg class="icon">
                                                <use href="#icon-email"></use>
                                            </svg>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
    </main>
</div>
<?php get_footer(); ?>

