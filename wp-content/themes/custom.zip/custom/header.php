<!DOCTYPE html>
<html lang="<?php bloginfo( 'language' ); ?>">

<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">

  <title><?php wp_title(); ?></title>

  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <link rel="apple-touch-icon" sizes="57x57" href="/apple-icon-57x57.png">
  <link rel="apple-touch-icon" sizes="60x60" href="/apple-icon-60x60.png">
  <link rel="apple-touch-icon" sizes="72x72" href="/apple-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="76x76" href="/apple-icon-76x76.png">
  <link rel="apple-touch-icon" sizes="114x114" href="/apple-icon-114x114.png">
  <link rel="apple-touch-icon" sizes="120x120" href="/apple-icon-120x120.png">
  <link rel="apple-touch-icon" sizes="144x144" href="/apple-icon-144x144.png">
  <link rel="apple-touch-icon" sizes="152x152" href="/apple-icon-152x152.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/apple-icon-180x180.png">
  <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
  <link rel="manifest" href="/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">

  <link rel="alternate" hreflang="ru-UA" href="<?php echo get_the_permalink(pll_get_post( get_the_ID(), 'ru' )) ?>" />
  <link rel="alternate" hreflang="en-US" href="<?php echo get_the_permalink(pll_get_post( get_the_ID(), 'en' )) ?>" />

  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div class="wrapper">
  <div class="content">
    <!--HEADER-->
    <header class="header">
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="header__content">
              <a class="header__logo-cont" href="<?php echo get_home_url(); ?>/">
                <img class="header__logo"src="<?php echo get_template_directory_uri() ?>/dist/img/icons/logo.svg" alt="logo">
              </a>
              <div class="menu__content">
                <?php
                  $args = array(
                    'container'     => '',
                    'theme_location' => 'main',
                    'menu_id' => '',
                  );
                  wp_nav_menu($args);
                ?>
              </div>
              <div class="language-switcher">
                <div class="language-switcher__current">
                  <?php
                    $current_language = pll_current_language();
                    echo strtoupper($current_language);
                  ?>
                  <button class="language-switcher__btn ">
                    <svg class="icon">
                      <use href="#arrow-down"></use>
                    </svg>
                  </button>
                </div>
                <ul class="language-switcher__list">
                  <?php
                    $languages = pll_the_languages(array('raw'=>1));
                    foreach ($languages as $language) {
                      echo '<li><a href="' . $language['url'] . '">' .  $language['slug'] . '</a> </li>';
                    }
                  ?>
                </ul>
              </div>
              <button class="header__btn button button_size_middle button_color_black button_type_inline js_modal-open" data-modal-id="popup-calculate"><?php echo pll__('header_button');?></button>

              <button class="hamburger hamburger--slider d-lg-none" type="button">
                <span class="hamburger-box">
                  <span class="hamburger-inner"></span>
                </span>
              </button> 

            </div>
          </div>
        </div>
      </div>
    </header>
    <!--HEADER-END-->
