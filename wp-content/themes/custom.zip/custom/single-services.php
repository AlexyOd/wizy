<div class="wrapper">
  <?php
  /*Template Name: Услуга*/
  get_header(); ?>
    <main class="main">
    <?php
        $breadcrumbs = get_template_directory() . '/parts/breadcrumbs.php';
        if (file_exists($breadcrumbs)) {
            $lang = pll_current_language() == 'ru' ? '/ru' : '';
            $link = get_site_url().$lang;
            $parents = array(
                array(
                    'link' => $link.'/services/',
                    'name' => pll__('pagename_services')
                ),
            );
            include $breadcrumbs;
        } else {
            echo 'Файл breadcrumbs.php не найден';
        }
    ?>
    
    <?php
        $services = get_field('services');
        $top_banner = get_field('top_banner');
        function isImageOrVideo($url) {
            // Получаем информацию о изображении
            $imageInfo = @getimagesize($url);
        
            // Проверяем, является ли ссылка изображением
            if ($imageInfo !== false) {
                return 'image';
            }
        
            // Если не изображение, проверяем расширение файла для видео
            $videoExtensions = array('mp4', 'webm', 'ogg'); // Добавьте расширения видео, которые вам интересны
        
            $fileExtension = pathinfo($url, PATHINFO_EXTENSION);
        
            if (in_array(strtolower($fileExtension), $videoExtensions)) {
                return 'video';
            }
        
            // Если не изображение и не видео, возвращаем 'other'
            return 'other';
        }
    ?>
    
    <?php
        $type = isImageOrVideo($top_banner);
        if ( $type == 'image') {
            
    ?>
        <div class="main-top">
            <div class="main-top__img">
                <img src="<?php echo $top_banner?>" alt="main_bg">
            </div>
        </div>
    <?php
        } elseif ($type == 'video') {
    ?>
        <video class="main-top__video" autoplay muted loop>
            <source src="<?php echo $top_banner ?>" type="video/mp4">
        </video>
    <?php
        }
    ?>

    <?php
        $title = get_field('title');
        $subtitle = get_field('subtitle');
    ?>
    <div class="service">
        <section class="service__subTop">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6 d-flex align-items-center">
                        <h1 class="section__title service__title">
                            <?php
                                echo $title
                            ?>
                        </h1>
                    </div>
                    <div class="col-12 col-md-6 d-flex align-items-center">
                        <p class="section__descr">
                            <?php
                                echo $subtitle
                            ?>
                        </p>
                    </div>
                </div>
            </div>

            <?php
                $svg_items = get_field('svg_items');
            ?>
            <div class="container">
                <div class="row">
                    <?php
                        foreach ($svg_items as $svg_item) {
                        $svg = $svg_item['svg'];
                        $title = $svg_item['title'];
                        $descr = $svg_item['descr'];
                    ?>
                        <div class="col-12 col-md-4">
                            <div class="service__svg-item">
                                <div class="service__svg-item__svg">
                                    <?php
                                        echo $svg
                                    ?>
                                </div>
                                <p class="service__svg-item__title">
                                    <?php
                                        echo $title
                                    ?>
                                </p>
                                <p class="service__svg-item__descr">
                                    <?php
                                        echo $descr
                                    ?>
                                </p>
                            </div>
                        </div>
                    <?php
                        }
                    ?>
                    
                </div>
            </div>
        </section>
        
        <?php
            $etapi = get_field('etapy_raboty');
            $title = $etapi['title'];
            $descr = $etapi['descr'];
            $items = $etapi['items'];

        ?>
        <section class="etapi">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <h1 class="section__title">
                            <?php
                                echo $title
                            ?>
                        </h1>
                    </div>
                    <div class="col-12 col-md-6">
                        <p class="section__descr">
                            <?php
                                echo $descr
                            ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="container etapi__loop">
                <div class="row">
                    <?php
                        foreach ($items as $index => $item) {
                            $title = $item['title'];
                            $descr = $item['descr'];
                    ?>
                        <div class="col-12 col-md-4 etapi__item-col">
                            <div class="etapi__item">
                                <div class="etapi__item-number">
                                    <?php
                                        echo $index+1
                                    ?>
                                </div>
                                <p class="etapi__item-title">
                                    <?php
                                        echo $title
                                    ?>
                                </p>
                                <p class="etapi__item-descr">
                                    <?php
                                        echo $descr
                                    ?>
                                </p>
                            </div>
                        </div>
                    <?php
                        }
                    ?>
                </div>
            </div>

        </section>
        <section class="section service__portfolio">
            <?php
                $portfolio = get_field('portfolio');
                $title = $portfolio['title'];
                $descr = $portfolio['descr'];
                $portfolio = $portfolio['projects'];
            ?>
            <div class="container">
                <div class="row ">
                    <div class="col-12 col-md-6">
                        <p class="section__title">
                            <?php
                                echo $title
                            ?>
                        </p>
                    </div>
                    <div class="col-12 col-md-6">
                        <p class="section__descr">
                            <?php
                                echo $descr
                            ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="service__portfolio-swiper swiper">
                <div class="swiper-wrapper">
                    <?php
                        foreach ($portfolio as $item) {
                            $titem = $item['item'];
                            $ID = $titem->ID;
                            $post_status = $titem->post_status;
                            if($post_status == 'publish') {
                                // $card_poster = get_field('card_poster',$ID);
                                // $card_nazvanie_kompanii = get_field('card_nazvanie_kompanii',$ID);
                                // $card_nazvanie_proekta = get_field('card_nazvanie_proekta',$ID);
                                // $card_location = get_field('card_location',$ID);
                                $card = array(
                                    'poster' => get_field('card_poster',$ID),
                                    'nazvanie_kompanii' => get_field('card_nazvanie_kompanii',$ID),
                                    'nazvanie_proekta' => get_field('card_nazvanie_proekta',$ID),
                                    'location' => get_field('card_location',$ID),
                                );
                    ?>
                        <div class="swiper-slide">
                            <div class="card">
                                <div class="card__poster">
                                    <img src="<?php echo $card['poster']?>" alt="<?php echo $card['nazvanie_kompanii'] ?>">
                                </div>
                                <div class="card__content">
                                    <div class="card__cname">
                                        <?php
                                            echo $card['nazvanie_kompanii']
                                        ?>
                                    </div>
                                    <div class="card__pname">
                                        <?php
                                            echo $card['nazvanie_proekta']
                                        ?>
                                    </div>
                                    <div class="card__location">
                                        <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_215_321)">
                                                <path d="M7.99923 1.38867C6.61487 1.38983 5.28722 1.93875 4.30625 2.91556C3.32529 3.89236 2.77072 5.21767 2.76367 6.60201C2.76367 8.67756 3.92812 10.4153 4.78145 11.682L4.93701 11.9131C5.78602 13.1436 6.69682 14.3303 7.66589 15.4687L8.00367 15.8642L8.34145 15.4687C9.31041 14.3302 10.2212 13.1435 11.0703 11.9131L11.2259 11.6776C12.0748 10.4109 13.2392 8.67756 13.2392 6.60201C13.2322 5.2169 12.677 3.89092 11.6951 2.91399C10.7131 1.93706 9.38435 1.38865 7.99923 1.38867ZM7.99923 8.94423C7.42259 8.94423 6.85889 8.77323 6.37943 8.45287C5.89997 8.1325 5.52628 7.67716 5.30561 7.14441C5.08493 6.61166 5.0272 6.02544 5.13969 5.45988C5.25219 4.89431 5.52987 4.37481 5.93762 3.96706C6.34537 3.55932 6.86487 3.28164 7.43043 3.16914C7.99599 3.05664 8.58221 3.11438 9.11496 3.33505C9.64771 3.55572 10.1031 3.92942 10.4234 4.40888C10.7438 4.88834 10.9148 5.45203 10.9148 6.02867C10.9148 6.80193 10.6076 7.54351 10.0608 8.09028C9.51406 8.63705 8.77248 8.94423 7.99923 8.94423Z" fill="#F35C26"/>
                                                <path d="M7.99957 7.68665C8.91514 7.68665 9.65735 6.94444 9.65735 6.02887C9.65735 5.11331 8.91514 4.37109 7.99957 4.37109C7.08401 4.37109 6.3418 5.11331 6.3418 6.02887C6.3418 6.94444 7.08401 7.68665 7.99957 7.68665Z" fill="#F35C26"/>
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_215_321">
                                                    <rect width="16" height="16" fill="white" transform="translate(0 0.5)"/>
                                                </clipPath>
                                            </defs>
                                        </svg>

                                        <?php
                                            echo $card['location']
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            }
                        ?>
                    <?php
                        }
                    ?>
                </div>

                <div class="service__portfolio-nav">

                </div>
            </div>
        </section>
        
        <?php
            $bottom_form = get_template_directory() . '/parts/bottom_form.php';
            if (file_exists($bottom_form)) {
                $home_page_id = get_option('page_on_front');
                $bottomForm = array(
                    'title' => get_field('bform_title',$home_page_id),
                    'subtitle' => get_field('bform_subtitle',$home_page_id),
                    'text' =>  get_field('bform_text',$home_page_id),
                    '$form' => get_field('bform', $home_page_id)
                );
                include $bottom_form;
            } else {
                echo 'Файл bottom_form.php не найден';
            }
        ?>

    </div>

    </main>
  </div>

  <?php get_footer(); ?>
